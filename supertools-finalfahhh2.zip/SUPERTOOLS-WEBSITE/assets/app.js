const N = (o) => document.querySelector(o), n = (o, e = {}, ...t) => {
  const a = document.createElement(o);
  for (const s in e)
    s.startsWith("on") ? a.addEventListener(s.slice(2), e[s]) : s === "class" ? a.className = e[s] : s in a ? a[s] = e[s] : a.setAttribute(s, e[s]);
  return t.flat().forEach((s) => s != null && s !== !1 && a.append(s.nodeType ? s : document.createTextNode(s))), a;
}, P = { g(o, e) {
  try {
    return JSON.parse(localStorage.getItem(o)) ?? e;
  } catch {
    return e;
  }
}, s(o, e) {
  try {
    localStorage.setItem(o, JSON.stringify(e));
  } catch {
  }
} }, z = (o) => o > 1e6 ? (o / 1e6).toFixed(2) + " MB" : (o / 1e3).toFixed(1) + " KB";
let _;
const x = (o, e = 2200) => {
  const t = N("#toast");
  t.textContent = o, t.style.display = "block", clearTimeout(_), _ = setTimeout(() => t.style.display = "none", e);
}, y = async (o) => {
  x("Working…", 1e5);
  try {
    await o(), x("Done ✓");
  } catch (e) {
    x("Error: " + (e.message || e), 5e3);
  }
}, p = (o, e, t = "") => n("button", { class: "btn " + t, onclick: e }, o), D = async (o) => {
  try {
    await navigator.clipboard.writeText(o), x("Copied ✓");
  } catch {
    x("Copy blocked — select the text manually");
  }
}, b = async (o, e) => {
  var s;
  o instanceof Blob || (o = new Blob([o]));
  let t = null;
  try {
    t = await ((s = window.claude) == null ? void 0 : s.use("downloads"));
  } catch {
  }
  if (t) {
    try {
      await t.save({ filename: e, data: o });
    } catch (r) {
      r.code !== "declined" && x("Save failed: " + (r.message || r.code));
    }
    return;
  }
  const a = n("a", { href: URL.createObjectURL(o), download: e });
  document.body.append(a), a.click(), a.remove();
}, $ = {
  pdf: async () => {
    window.PDFLib = await import("./index-yZg2NkOO.js");
  },
  zip: async () => {
    window.JSZip = (await import("./jszip.min-CwiYjKvC.js").then((o) => o.j)).default;
  },
  qr: async () => {
    window.qrcode = (await import("./qrcode-DdA7sV4P.js").then((o) => o.q)).default;
  },
  pjs: async () => {
    const [o, e] = await Promise.all([import("./pdf-D9PLOoq3.js").then((t) => t.p), import("./pdf.worker.min-cTqfN7tf.js").then((t) => t.p)]);
    window.pdfjsWorker = e.WorkerMessageHandler ? e : e.default || e, window.pdfjsLib = o;
  }
}, M = (o, e, t, a) => {
  const s = n("input", { type: "file", accept: o, multiple: e, hidden: !0, onchange: () => {
    t([...s.files]), s.value = "";
  } }), r = n("div", { class: "drop", onclick: () => s.click(), ondragover: (i) => {
    i.preventDefault(), r.classList.add("on");
  }, ondragleave: () => r.classList.remove("on"), ondrop: (i) => {
    i.preventDefault(), r.classList.remove("on"), t([...i.dataTransfer.files]);
  } }, a || "Click or drop files here");
  return n("div", {}, r, s);
}, ae = (o, e) => {
  const t = [];
  for (const a of o.split(",")) {
    const s = a.trim().match(/^(\d+)(?:-(\d+))?$/);
    if (!s) throw Error('Bad range: "' + a.trim() + '"');
    const r = +s[1], i = +(s[2] || s[1]);
    if (r < 1 || i > e || r > i) throw Error("Out of range (1–" + e + "): " + a.trim());
    for (let c = r; c <= i; c++) t.push(c - 1);
  }
  return t;
}, A = (o, e, t) => new Promise((a) => o.toBlob(a, e, t)), U = async (o) => {
  await $.zip();
  const e = new JSZip();
  return o.forEach(([t, a]) => e.file(t, a)), e.generateAsync({ type: "blob", compression: "DEFLATE" });
}, O = (o) => o.replace(/\.[^.]+$/, "");
function Z(o, e) {
  let t = [];
  const a = n("div", { class: "list" }), s = n("input", { type: "range", min: 0.1, max: 1, step: 0.05, value: e ? 0.92 : 0.7 }), r = n("span", { class: "mut" }), i = n("input", { type: "number", min: 1, placeholder: e ? "Width px" : "Max width px (optional)", style: "width:170px" }), c = n("input", { type: "number", min: 1, placeholder: "Height px", style: "width:120px" }), l = n("select", {}, ...(e ? ["png", "jpeg", "webp"] : ["jpeg", "webp"]).map((u) => n("option", { value: u }, u.toUpperCase())));
  s.oninput = () => r.textContent = Math.round(s.value * 100) + "%", s.oninput();
  const d = () => y(async () => {
    if (!t.length) throw Error("Add images first");
    const u = [];
    a.replaceChildren();
    for (const h of t) {
      const m = await createImageBitmap(h);
      let g = +i.value || 0, v = e && +c.value || 0;
      e ? (g = g || (v ? Math.round(m.width * v / m.height) : m.width), v = v || (+i.value ? Math.round(m.height * g / m.width) : m.height)) : ((!g || g > m.width) && (g = m.width), v = Math.round(m.height * g / m.width));
      const C = n("canvas");
      C.width = g, C.height = v;
      const E = C.getContext("2d");
      l.value === "jpeg" && (E.fillStyle = "#fff", E.fillRect(0, 0, g, v)), E.drawImage(m, 0, 0, g, v);
      const f = await A(C, "image/" + l.value, +s.value), w = O(h.name) + (e ? `-${g}x${v}` : "-min") + "." + (l.value === "jpeg" ? "jpg" : l.value);
      u.push([w, f]), a.append(n("div", { class: "row" }, n("span", {}, w), n("span", { class: "mut" }, `${z(h.size)} → ${z(f.size)}${e ? "" : " (" + Math.round((1 - f.size / h.size) * 100) + "% smaller)"}`), n("span", { class: "sp" }), p("Save", () => b(f, w))));
    }
    u.length > 1 && a.append(p("Save all as ZIP", () => y(async () => b(await U(u), "images.zip")), "pri"));
  });
  o.append(
    M("image/*", !0, (u) => {
      t = u.filter((h) => h.type.startsWith("image/")), a.replaceChildren(n("div", { class: "mut" }, t.length + " image(s) ready"));
    }, "Click or drop images here"),
    n("div", { class: "row" }, i, e && c, n("label", {}, "Format"), l, n("label", {}, "Quality"), s, r),
    e && n("div", { class: "mut" }, "Fill one size to keep the aspect ratio, or both for an exact size."),
    p(e ? "Resize" : "Compress", d, "pri"),
    a
  );
}
const ie = [
  { id: "pdf-merger", n: "PDF Merger", c: "pdf", i: "📚", d: "Merge multiple PDF files into one document.", run(o) {
    let e = [];
    const t = n("div", { class: "list" }), a = () => t.replaceChildren(...e.map((s, r) => n("div", { class: "row" }, n("span", {}, s.name), n("span", { class: "mut" }, z(s.size)), n("span", { class: "sp" }), p("↑", () => {
      r && ([e[r - 1], e[r]] = [e[r], e[r - 1]], a());
    }), p("↓", () => {
      r < e.length - 1 && ([e[r + 1], e[r]] = [e[r], e[r + 1]], a());
    }), p("✕", () => {
      e.splice(r, 1), a();
    }))));
    o.append(M(".pdf,application/pdf", !0, (s) => {
      e.push(...s.filter((r) => /\.pdf$/i.test(r.name))), a();
    }, "Click or drop PDFs here (order = merge order)"), t, p("Merge & download", () => y(async () => {
      if (e.length < 2) throw Error("Add at least 2 PDFs");
      await $.pdf();
      const s = await PDFLib.PDFDocument.create();
      for (const r of e) {
        const i = await PDFLib.PDFDocument.load(await r.arrayBuffer(), { ignoreEncryption: !0 });
        (await s.copyPages(i, i.getPageIndices())).forEach((c) => s.addPage(c));
      }
      b(new Blob([await s.save()]), "merged.pdf");
    }), "pri"));
  } },
  { id: "pdf-splitter", n: "PDF Splitter", c: "pdf", i: "✂️", d: "Split a PDF into selected pages or page ranges.", run(o) {
    let e, t, a = 0;
    const s = n("div", { class: "mut" }), r = n("input", { placeholder: "e.g. 1-3, 5, 8-10", style: "width:260px" }), i = async () => (await $.pdf(), PDFLib.PDFDocument.load(await e.arrayBuffer(), { ignoreEncryption: !0 }));
    o.append(
      M(".pdf,application/pdf", !1, (c) => y(async () => {
        e = c[0], t = await i(), a = t.getPageCount(), s.textContent = e.name + " — " + a + " pages";
      })),
      s,
      n("div", { class: "row" }, n("label", {}, "Pages"), r),
      n(
        "div",
        { class: "row" },
        p("Extract pages → one PDF", () => y(async () => {
          if (!t) throw Error("Choose a PDF first");
          const c = ae(r.value, a), l = await PDFLib.PDFDocument.create();
          (await l.copyPages(t, c)).forEach((d) => l.addPage(d)), b(new Blob([await l.save()]), O(e.name) + "-extract.pdf");
        }), "pri"),
        p("Every page → ZIP", () => y(async () => {
          if (!t) throw Error("Choose a PDF first");
          const c = [];
          for (let l = 0; l < a; l++) {
            const d = await PDFLib.PDFDocument.create();
            d.addPage((await d.copyPages(t, [l]))[0]), c.push([`${O(e.name)}-p${l + 1}.pdf`, await d.save()]);
          }
          b(await U(c), O(e.name) + "-pages.zip");
        }))
      )
    );
  } },
  { id: "pdf-to-images", n: "PDF to Images", c: "pdf", i: "🖼️", d: "Convert PDF pages into PNG image files.", run(o) {
    const e = n("div", { class: "thumbs" }), t = n("select", {}, ...[1, 1.5, 2, 3].map((s) => n("option", { value: s, selected: s === 2 }, s + "× quality")));
    let a = [];
    o.append(
      M(".pdf,application/pdf", !1, (s) => y(async () => {
        await $.pjs(), e.replaceChildren(), a = [];
        const r = await pdfjsLib.getDocument({ data: await s[0].arrayBuffer() }).promise;
        for (let i = 1; i <= r.numPages; i++) {
          const c = await r.getPage(i), l = c.getViewport({ scale: +t.value }), d = n("canvas");
          d.width = l.width, d.height = l.height, await c.render({ canvasContext: d.getContext("2d"), viewport: l }).promise;
          const u = await A(d, "image/png"), h = `${O(s[0].name)}-p${i}.png`;
          a.push([h, u]), e.append(n("div", {}, n("img", { src: URL.createObjectURL(u) }), n("div", { class: "row" }, n("span", { class: "mut" }, "Page " + i), n("span", { class: "sp" }), p("Save", () => b(u, h)))));
        }
      })),
      n("div", { class: "row" }, n("label", {}, "Quality"), t, p("Save all as ZIP", () => y(async () => {
        if (!a.length) throw Error("Convert a PDF first");
        b(await U(a), "pdf-pages.zip");
      }), "pri")),
      e
    );
  } },
  { id: "image-compressor", n: "Image Compressor", c: "image", i: "🗜️", d: "Reduce image file size while keeping useful quality.", run: (o) => Z(o, !1) },
  { id: "image-resizer", n: "Image Resizer", c: "image", i: "↔️", d: "Resize images using custom dimensions.", run: (o) => Z(o, !0) },
  { id: "zip-creator", n: "ZIP Creator", c: "files", i: "🗃️", d: "Create ZIP archives directly in your browser.", run(o) {
    let e = [];
    const t = n("div", { class: "list" }), a = n("input", { value: "archive" }), s = () => t.replaceChildren(...e.map((r, i) => n("div", { class: "row" }, n("span", {}, r.name), n("span", { class: "mut" }, z(r.size)), n("span", { class: "sp" }), p("✕", () => {
      e.splice(i, 1), s();
    }))));
    o.append(M("", !0, (r) => {
      e.push(...r), s();
    }, "Click or drop any files"), t, n("div", { class: "row" }, a, n("span", { class: "mut" }, ".zip"), p("Create ZIP", () => y(async () => {
      if (!e.length) throw Error("Add some files");
      b(await U(e.map((r) => [r.name, r])), (a.value || "archive") + ".zip");
    }), "pri")));
  } },
  { id: "json-formatter", n: "JSON Formatter", c: "dev", i: "🧩", d: "Format, validate and minify JSON data.", run(o) {
    const e = n("textarea", { placeholder: "Paste JSON here…" }), t = n("div", { class: "mut" }), a = n("select", {}, n("option", { value: 2 }, "2 spaces"), n("option", { value: 4 }, "4 spaces"), n("option", { value: "	" }, "Tab")), s = (r) => () => {
      try {
        const i = JSON.parse(e.value);
        e.value = r(i), t.style.color = "var(--ok)", t.textContent = "✓ Valid JSON";
      } catch (i) {
        t.style.color = "var(--bad)", t.textContent = "✗ " + i.message;
      }
    };
    o.append(e, n("div", { class: "row" }, p("Format", s((r) => JSON.stringify(r, null, a.value === "	" ? "	" : +a.value)), "pri"), p("Minify", s((r) => JSON.stringify(r))), p("Validate", s(() => e.value)), a, p("Copy", () => D(e.value))), t);
  } },
  { id: "base64", n: "Base64 Encoder", c: "dev", i: "🔣", d: "Encode and decode Base64 text locally.", run(o) {
    const e = n("textarea", { placeholder: "Text or Base64…" }), t = n("div", { class: "mut" });
    o.append(e, n(
      "div",
      { class: "row" },
      p("Encode", () => {
        let a = "";
        new TextEncoder().encode(e.value).forEach((s) => a += String.fromCharCode(s)), e.value = btoa(a), t.textContent = "";
      }, "pri"),
      p("Decode", () => {
        try {
          e.value = new TextDecoder().decode(Uint8Array.from(atob(e.value.trim().replace(/-/g, "+").replace(/_/g, "/")), (a) => a.charCodeAt(0))), t.textContent = "";
        } catch {
          t.style.color = "var(--bad)", t.textContent = "✗ Not valid Base64";
        }
      }),
      p("Copy", () => D(e.value))
    ), t);
  } },
  { id: "uuid-generator", n: "UUID Generator", c: "gen", i: "🆔", d: "Generate UUID v4 identifiers locally.", run(o) {
    const e = n("input", { type: "number", min: 1, max: 500, value: 5, style: "width:90px" }), t = n("textarea", { readOnly: !0, style: "min-height:180px" }), a = () => t.value = Array.from({ length: Math.min(500, Math.max(1, +e.value || 1)) }, () => crypto.randomUUID()).join(`
`);
    a(), o.append(n("div", { class: "row" }, n("label", {}, "How many"), e, p("Generate", a, "pri"), p("Copy", () => D(t.value))), t);
  } },
  { id: "qr-generator", n: "QR Code Generator", c: "gen", i: "🔳", d: "Generate QR codes directly in your browser.", run(o) {
    const e = n("textarea", { style: "min-height:90px", placeholder: "Text or URL…" }), t = n("canvas", { style: "max-width:100%;border-radius:8px;background:#fff" }), a = n("select", {}, ...["L", "M", "Q", "H"].map((i) => n("option", { value: i, selected: i === "M" }, "Error fix " + i))), s = n("select", {}, ...[256, 512, 1024].map((i) => n("option", { value: i, selected: i === 512 }, i + " px"))), r = () => y(async () => {
      if (!e.value) return;
      await $.qr();
      const i = qrcode(0, a.value);
      i.addData(e.value), i.make();
      const c = i.getModuleCount(), l = Math.max(1, Math.floor(+s.value / (c + 8))), d = (c + 8) * l;
      t.width = t.height = d;
      const u = t.getContext("2d");
      u.fillStyle = "#fff", u.fillRect(0, 0, d, d), u.fillStyle = "#000";
      for (let h = 0; h < c; h++) for (let m = 0; m < c; m++) i.isDark(h, m) && u.fillRect((m + 4) * l, (h + 4) * l, l, l);
    });
    e.oninput = r, a.onchange = r, s.onchange = r, o.append(e, n("div", { class: "row" }, a, s, p("Save PNG", async () => {
      if (!e.value) return x("Enter some text first");
      b(await A(t, "image/png"), "qrcode.png");
    }, "pri")), t);
  } },
  { id: "password-generator", n: "Password Generator", c: "gen", i: "🔑", d: "Generate strong random passwords locally.", run(o) {
    const e = n("input", { type: "range", min: 8, max: 64, value: 20 }), t = n("b", {}, "20"), a = n("input", { readOnly: !0, style: "width:100%;font:18px ui-monospace,monospace" }), s = n("div", { class: "mut" }), r = { Lowercase: "abcdefghijkmnopqrstuvwxyz", Uppercase: "ABCDEFGHJKLMNPQRSTUVWXYZ", Numbers: "23456789", Symbols: "!@#$%^&*()-_=+[]{};:,.?" }, i = {}, c = (d) => {
      const u = new Uint32Array(1), h = 2 ** 32 - 2 ** 32 % d;
      do
        crypto.getRandomValues(u);
      while (u[0] >= h);
      return u[0] % d;
    }, l = () => {
      const d = Object.keys(r).filter((v) => i[v].checked);
      if (!d.length) {
        a.value = "", s.textContent = "Pick at least one set";
        return;
      }
      const u = d.map((v) => r[v]).join(""), h = +e.value;
      t.textContent = h;
      const m = d.map((v) => r[v][c(r[v].length)]);
      for (; m.length < h; ) m.push(u[c(u.length)]);
      for (let v = m.length - 1; v > 0; v--) {
        const C = c(v + 1);
        [m[v], m[C]] = [m[C], m[v]];
      }
      a.value = m.join("");
      const g = Math.round(h * Math.log2(u.length));
      s.textContent = `≈ ${g} bits of entropy — ${g < 60 ? "weak" : g < 90 ? "good" : "excellent"}`;
    };
    e.oninput = l, o.append(a, n("div", { class: "row" }, n("label", {}, "Length"), e, t), n("div", { class: "row" }, ...Object.keys(r).map((d) => n("label", {}, i[d] = n("input", { type: "checkbox", checked: !0, onchange: l }), " " + d))), s, n("div", { class: "row" }, p("Generate", l, "pri"), p("Copy", () => D(a.value)))), l();
  } },
  { id: "word-counter", n: "Word Counter", c: "text", i: "🔢", d: "Count words, characters, sentences and paragraphs.", run(o) {
    const e = n("textarea", { placeholder: "Type or paste text…" }), t = n("div", { class: "stats" }), a = () => {
      const s = e.value, r = (s.match(/[\p{L}\p{N}'’-]+/gu) || []).length, i = [["Words", r], ["Characters", s.length], ["No spaces", s.replace(/\s/g, "").length], ["Sentences", (s.match(/[^.!?]+[.!?]+/g) || (s.trim() ? [1] : [])).length], ["Paragraphs", s.split(/\n\s*\n/).filter((c) => c.trim()).length], ["Reading time", Math.ceil(r / 200) + " min"]];
      t.replaceChildren(...i.map(([c, l]) => n("div", {}, n("b", {}, l), c)));
    };
    e.oninput = a, a(), o.append(t, e);
  } },
  { id: "case-converter", n: "Case Converter", c: "text", i: "🔠", d: "Convert text between different letter cases.", run(o) {
    const e = n("textarea", { placeholder: "Type or paste text…" }), t = (r) => r.replace(/([a-z0-9])([A-Z])/g, "$1 $2").match(/[\p{L}\p{N}]+/gu) || [], a = (r) => r[0].toUpperCase() + r.slice(1).toLowerCase(), s = {
      "UPPER CASE": (r) => r.toUpperCase(),
      "lower case": (r) => r.toLowerCase(),
      "Title Case": (r) => r.toLowerCase().replace(new RegExp("(^|\\s|[-(])(\\p{L})", "gu"), (i, c, l) => c + l.toUpperCase()),
      "Sentence case": (r) => r.toLowerCase().replace(new RegExp("(^\\s*|[.!?]\\s+)(\\p{L})", "gu"), (i, c, l) => c + l.toUpperCase()),
      camelCase: (r) => t(r).map((i, c) => c ? a(i) : i.toLowerCase()).join(""),
      PascalCase: (r) => t(r).map(a).join(""),
      snake_case: (r) => t(r).join("_").toLowerCase(),
      "kebab-case": (r) => t(r).join("-").toLowerCase(),
      CONSTANT_CASE: (r) => t(r).join("_").toUpperCase()
    };
    o.append(e, n("div", { class: "row" }, ...Object.entries(s).map(([r, i]) => p(r, () => e.value = i(e.value)))), n("div", { class: "row" }, p("Copy", () => D(e.value), "pri")));
  } },
  { id: "pomodoro", n: "Pomodoro Timer", c: "prod", i: "🍅", d: "Focus with customizable work and break sessions.", run(o) {
    const e = { w: 25, s: 5, l: 15 }, t = {};
    let a = "w", s = e.w * 60, r = 0, i = null, c = 0;
    const l = n("div", { class: "big" }), d = n("div", { class: "mut", style: "text-align:center" }), u = { w: "Focus", s: "Short break", l: "Long break" }, h = () => {
      const f = String(Math.floor(s / 60)).padStart(2, "0"), w = String(s % 60).padStart(2, "0");
      l.textContent = f + ":" + w, d.textContent = `${u[a]} · ${c} session(s) done`, document.title = (i ? f + ":" + w + " · " : "") + "SUPERTOOLS";
    }, m = () => {
      try {
        const f = new AudioContext(), w = f.createOscillator();
        w.connect(f.destination), w.frequency.value = 880, w.start(), w.stop(f.currentTime + 0.6);
      } catch {
      }
    }, g = (f) => {
      a = f, s = Math.round((+t[f].value || e[f]) * 60), r = Date.now() + s * 1e3, h();
    }, v = () => {
      s = Math.max(0, Math.round((r - Date.now()) / 1e3)), s || (m(), x(u[a] + " finished!", 4e3), a === "w" ? (c++, g(c % 4 ? "s" : "l")) : g("w")), h();
    }, C = () => {
      i || (r = Date.now() + s * 1e3, i = setInterval(v, 250), h());
    }, E = () => {
      clearInterval(i), i = null, h();
    };
    o.append(
      d,
      l,
      n("div", { class: "row", style: "justify-content:center" }, p("Start", C, "pri"), p("Pause", E), p("Reset", () => {
        E(), g(a);
      }), p("Skip →", () => {
        E(), g(a === "w" ? "s" : "w");
      })),
      n("div", { class: "row", style: "justify-content:center" }, ...[["w", "Focus"], ["s", "Short"], ["l", "Long"]].map(([f, w]) => n("label", {}, w + " min ", t[f] = n("input", { type: "number", min: 1, max: 180, value: e[f], style: "width:70px", onchange: () => {
        f === a && !i && g(a);
      } }))))
    ), h();
  } },
  { id: "flashcards", n: "Flashcards", c: "edu", i: "🗂️", d: "Create and review your own flashcard decks.", run(o) {
    let e = P.g("st-decks", {}), t = Object.keys(e)[0] || "", a = [], s = !1, r = !1;
    const i = () => P.s("st-decks", e), c = n("div", { class: "panel" });
    o.append(c);
    const l = () => {
      a = e[t].map((u, h) => h).sort(() => Math.random() - 0.5), s = !1;
    }, d = () => {
      const u = n("select", { onchange: () => {
        t = u.value, l(), d();
      } }, ...Object.keys(e).map((f) => n("option", { value: f, selected: f === t }, f))), h = n("input", { placeholder: "New deck name" }), m = n("div", { class: "row" }, Object.keys(e).length ? u : n("span", { class: "mut" }, "No decks yet →"), h, p("Create", () => {
        const f = h.value.trim();
        f && !e[f] && (e[f] = [], t = f, i(), l(), d());
      }), t && p(r ? "Click again to delete" : "Delete deck", () => {
        if (!r) {
          r = !0, d();
          return;
        }
        delete e[t], t = Object.keys(e)[0] || "", r = !1, i(), t && l(), d();
      }));
      if (c.replaceChildren(m), !t) return;
      const g = e[t];
      if (g.length)
        if (!a.length && g.length) c.append(n("div", { class: "fc", style: "cursor:default" }, "🎉 Deck complete!"), p("Review again", () => {
          l(), d();
        }));
        else {
          const f = g[a[0]];
          c.append(n("div", { class: "mut" }, a.length + " left to review"), n("div", { class: "fc", onclick: () => {
            s = !s, d();
          } }, s ? f.a : f.q), n("div", { class: "row" }, p(s ? "Hide answer" : "Show answer", () => {
            s = !s, d();
          }), n("span", { class: "sp" }), p("Again", () => {
            a.push(a.shift()), s = !1, d();
          }), p("Got it ✓", () => {
            a.shift(), s = !1, d();
          }, "pri")));
        }
      const v = n("input", { placeholder: "Question", style: "flex:1" }), C = n("input", { placeholder: "Answer", style: "flex:1" }), E = n("textarea", { style: "min-height:70px", placeholder: "Bulk add — one per line:  question :: answer" });
      c.append(
        n("div", { class: "row" }, v, C, p("Add card", () => {
          v.value && C.value && (g.push({ q: v.value, a: C.value }), i(), l(), d());
        })),
        E,
        p("Import lines", () => {
          E.value.split(`
`).forEach((f) => {
            const [w, ...V] = f.split("::");
            w.trim() && V.join("::").trim() && g.push({ q: w.trim(), a: V.join("::").trim() });
          }), i(), l(), d();
        }),
        ...g.map((f, w) => n("div", { class: "row mut" }, n("span", {}, f.q + " — " + f.a), n("span", { class: "sp" }), p("✕", () => {
          g.splice(w, 1), i(), l(), d();
        })))
      );
    };
    t && l(), d();
  } }
], le = () => {
  try {
    const o = new AudioContext(), e = o.createOscillator();
    e.connect(o.destination), e.frequency.value = 880, e.start(), e.stop(o.currentTime + 0.6);
  } catch {
  }
}, S = (o) => {
  const e = new Uint32Array(1), t = 2 ** 32 - 2 ** 32 % o;
  do
    crypto.getRandomValues(e);
  while (e[0] >= t);
  return e[0] % o;
}, B = (o, e, t) => "#" + [o, e, t].map((a) => a.toString(16).padStart(2, "0")).join(""), ce = (o, e, t) => {
  e /= 100, t /= 100;
  const a = (i) => (i + o / 30) % 12, s = e * Math.min(t, 1 - t), r = (i) => t - s * Math.max(-1, Math.min(a(i) - 3, 9 - a(i), 1));
  return [r(0), r(8), r(4)].map((i) => Math.round(i * 255));
}, de = (o, e, t) => {
  o /= 255, e /= 255, t /= 255;
  const a = Math.max(o, e, t), s = Math.min(o, e, t), r = a - s, i = (a + s) / 2;
  let c = 0, l = 0;
  return r && (l = r / (1 - Math.abs(2 * i - 1)), c = a === o ? ((e - t) / r + 6) % 6 : a === e ? (t - o) / r + 2 : (o - e) / r + 4, c *= 60), [Math.round(c), Math.round(l * 100), Math.round(i * 100)];
}, L = (o, e, t) => {
  const a = n("textarea", { placeholder: t || "Input…" }), s = n("textarea", { readOnly: !0, placeholder: "Output" });
  o.append(a, n("div", { class: "row" }, ...Object.entries(e).map(([r, i], c) => p(r, async () => {
    try {
      s.value = await i(a.value);
    } catch (l) {
      s.value = "", x("Error: " + l.message, 4e3);
    }
  }, c ? "" : "pri")), p("Copy", () => D(s.value))), s);
}, k = (o, e, t) => {
  const a = e.map(([, i, c, l]) => l ? n("select", {}, ...l.map((d) => n("option", { value: d, selected: d === c }, d))) : n("input", { type: i || "number", value: c ?? "", step: "any" })), s = n("div", { class: "stats" }), r = () => {
    try {
      s.replaceChildren(...t(...a.map((i) => i.value)).map(([i, c]) => n("div", {}, n("b", {}, c), i)));
    } catch (i) {
      s.replaceChildren(n("div", {}, n("b", {}, "—"), i.message));
    }
  };
  a.forEach((i) => {
    i.oninput = r, i.onchange = r;
  }), o.append(...e.map(([i], c) => n("div", { class: "row" }, n("label", { style: "width:170px" }, i), a[c])), s), r();
}, X = (o, e, t, a, s) => {
  let r, i;
  const c = n("div", { class: "mut" });
  o.append(
    M(".pdf,application/pdf", !1, (l) => y(async () => {
      r = l[0], await $.pdf(), i = await PDFLib.PDFDocument.load(await r.arrayBuffer(), { ignoreEncryption: !0 }), c.textContent = r.name + " — " + i.getPageCount() + " pages";
    })),
    c,
    ...e,
    p(a, () => y(async () => {
      if (!i) throw Error("Choose a PDF first");
      const l = await t(i);
      b(new Blob([await l.save()]), O(r.name) + s);
    }), "pri")
  );
}, pe = (o) => new Promise((e, t) => {
  const a = new FileReader();
  a.onload = () => e(a.result), a.onerror = t, a.readAsDataURL(o);
}), H = async (o) => createImageBitmap(o), ue = (o) => {
  const e = [];
  let t = [], a = "", s = !1;
  for (let r = 0; r < o.length; r++) {
    const i = o[r];
    s ? i === '"' ? o[r + 1] === '"' ? (a += '"', r++) : s = !1 : a += i : i === '"' ? s = !0 : i === "," ? (t.push(a), a = "") : i === `
` || i === "\r" ? (i === "\r" && o[r + 1] === `
` && r++, t.push(a), e.push(t), t = [], a = "") : a += i;
  }
  return (a || t.length) && (t.push(a), e.push(t)), e;
}, Q = (o) => new TextDecoder().decode(Uint8Array.from(atob(o.replace(/-/g, "+").replace(/_/g, "/")), (e) => e.charCodeAt(0))), G = { a: ".-", b: "-...", c: "-.-.", d: "-..", e: ".", f: "..-.", g: "--.", h: "....", i: "..", j: ".---", k: "-.-", l: ".-..", m: "--", n: "-.", o: "---", p: ".--.", q: "--.-", r: ".-.", s: "...", t: "-", u: "..-", v: "...-", w: ".--", x: "-..-", y: "-.--", z: "--..", 0: "-----", 1: ".----", 2: "..---", 3: "...--", 4: "....-", 5: ".....", 6: "-....", 7: "--...", 8: "---..", 9: "----.", ".": ".-.-.-", ",": "--..--", "?": "..--..", "!": "-.-.--" }, he = (o, e) => {
  const t = o.length, a = e.length, s = Array.from({ length: t + 1 }, () => new Uint16Array(a + 1));
  for (let l = t - 1; l >= 0; l--) for (let d = a - 1; d >= 0; d--) s[l][d] = o[l] === e[d] ? s[l + 1][d + 1] + 1 : Math.max(s[l + 1][d], s[l][d + 1]);
  let r = 0, i = 0;
  const c = [];
  for (; r < t && i < a; )
    o[r] === e[i] ? (c.push([" ", o[r]]), r++, i++) : s[r + 1][i] >= s[r][i + 1] ? c.push(["-", o[r++]]) : c.push(["+", e[i++]]);
  for (; r < t; ) c.push(["-", o[r++]]);
  for (; i < a; ) c.push(["+", e[i++]]);
  return c;
}, me = (o) => {
  o = o.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  let e = "", t = !1, a = !1;
  for (const s of o.split(`
`)) {
    if (s.startsWith("```")) {
      e += a ? "</code></pre>" : "<pre><code>", a = !a;
      continue;
    }
    if (a) {
      e += s + `
`;
      continue;
    }
    let r;
    (r = s.match(/^(#{1,6})\s+(.*)/)) ? (t && (e += "</ul>", t = !1), e += `<h${r[1].length}>${r[2]}</h${r[1].length}>`) : (r = s.match(/^\s*[-*]\s+(.*)/)) ? (t || (e += "<ul>", t = !0), e += "<li>" + r[1] + "</li>") : (t && (e += "</ul>", t = !1), e += s.trim() ? "<p>" + s + "</p>" : "");
  }
  return t && (e += "</ul>"), a && (e += "</code></pre>"), e.replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/\*(.+?)\*/g, "<i>$1</i>").replace(/`(.+?)`/g, "<code>$1</code>").replace(/\[(.+?)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
}, W = ["", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"], ge = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"], fe = (o) => o < 20 ? W[o] : ge[o / 10 | 0] + (o % 10 ? "-" + W[o % 10] : ""), ve = (o) => (o >= 100 ? W[o / 100 | 0] + " hundred" + (o % 100 ? " " : "") : "") + (o % 100 ? fe(o % 100) : ""), ne = (o) => {
  if (o === 0) return "zero";
  const e = [];
  for (const [t, a] of [[1e7, "crore"], [1e5, "lakh"], [1e3, "thousand"]]) o >= t && (e.push(ne(Math.floor(o / t)) + " " + a), o %= t);
  return o && e.push(ve(o)), e.join(" ");
}, J = { Length: { m: 1, km: 1e3, cm: 0.01, mm: 1e-3, mi: 1609.344, yd: 0.9144, ft: 0.3048, in: 0.0254 }, Mass: { kg: 1, g: 1e-3, mg: 1e-6, tonne: 1e3, lb: 0.45359237, oz: 0.028349523 }, Data: { B: 1, KB: 1024, MB: 1048576, GB: 1073741824, TB: 1099511627776 }, Time: { s: 1, min: 60, hour: 3600, day: 86400, week: 604800 }, Speed: { "m/s": 1, "km/h": 1 / 3.6, mph: 0.44704, knot: 0.514444 }, Area: { "m²": 1, "km²": 1e6, hectare: 1e4, acre: 4046.8564, "ft²": 0.09290304 }, Volume: { L: 1, mL: 1e-3, "m³": 1e3, gal: 3.785411784, cup: 0.2365882365 }, Temperature: { "°C": 1, "°F": 1, K: 1 } }, we = (o, e, t) => {
  const a = e === "°C" ? o : e === "°F" ? (o - 32) * 5 / 9 : o - 273.15;
  return t === "°C" ? a : t === "°F" ? a * 9 / 5 + 32 : a + 273.15;
}, K = "lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua enim ad minim veniam quis nostrud exercitation ullamco laboris nisi aliquip ex ea commodo consequat duis aute irure in reprehenderit voluptate velit esse cillum fugiat nulla pariatur excepteur sint occaecat cupidatat non proident sunt culpa qui officia deserunt mollit anim id est laborum".split(" "), ee = ["The quick brown fox jumps over the lazy dog near the quiet river bank.", "Practice makes progress, so keep typing a little every single day.", "Great apps start as small ideas that someone decides to actually build.", "Cricket is a game of patience, timing, and a little bit of luck."], j = (o) => (Math.abs(o) < 1e-4 && o !== 0 ? o.toExponential(4) : +o.toFixed(6)).toString(), ye = [
  /* ---------------- PDF ---------------- */
  { id: "pdf-to-text", n: "PDF to Text", c: "pdf", i: "📝", d: "Extract selectable text from a PDF.", run(o) {
    const e = n("textarea", { readOnly: !0, style: "min-height:300px" });
    o.append(M(".pdf,application/pdf", !1, (t) => y(async () => {
      await $.pjs();
      const a = await pdfjsLib.getDocument({ data: await t[0].arrayBuffer() }).promise;
      let s = "";
      for (let r = 1; r <= a.numPages; r++) {
        const i = await (await a.getPage(r)).getTextContent();
        s += `--- Page ${r} ---
` + i.items.map((c) => c.str + (c.hasEOL ? `
` : "")).join("") + `

`;
      }
      e.value = s.trim() || "No selectable text found (scanned PDFs need OCR).";
    })), n("div", { class: "row" }, p("Copy", () => D(e.value)), p("Save .txt", () => b(e.value, "extracted.txt"))), e);
  } },
  { id: "pdf-rotate", n: "PDF Rotator", c: "pdf", i: "🔄", d: "Rotate every page of a PDF.", run(o) {
    const e = n("select", {}, ...[90, 180, 270].map((t) => n("option", { value: t }, t + "° clockwise")));
    X(o, [n("div", { class: "row" }, n("label", {}, "Rotate"), e)], (t) => (t.getPages().forEach((a) => a.setRotation(PDFLib.degrees((a.getRotation().angle + +e.value) % 360))), t), "Rotate & download", "-rotated.pdf");
  } },
  { id: "pdf-page-remover", n: "PDF Page Remover", c: "pdf", i: "🗑️", d: "Delete unwanted pages from a PDF.", run(o) {
    const e = n("input", { placeholder: "Pages to delete e.g. 2, 4-6", style: "width:260px" });
    X(o, [e], async (t) => {
      const a = t.getPageCount(), s = new Set(ae(e.value, a)), r = [...Array(a).keys()].filter((c) => !s.has(c));
      if (!r.length) throw Error("That would delete every page");
      const i = await PDFLib.PDFDocument.create();
      return (await i.copyPages(t, r)).forEach((c) => i.addPage(c)), i;
    }, "Remove & download", "-trimmed.pdf");
  } },
  { id: "images-to-pdf", n: "Images to PDF", c: "pdf", i: "🧾", d: "Combine images into a single PDF.", run(o) {
    let e = [];
    const t = n("div", { class: "list" }), a = () => t.replaceChildren(...e.map((s, r) => n("div", { class: "row" }, n("span", {}, s.name), n("span", { class: "sp" }), p("↑", () => {
      r && ([e[r - 1], e[r]] = [e[r], e[r - 1]], a());
    }), p("✕", () => {
      e.splice(r, 1), a();
    }))));
    o.append(M("image/*", !0, (s) => {
      e.push(...s.filter((r) => r.type.startsWith("image/"))), a();
    }, "Click or drop images (in page order)"), t, p("Create PDF", () => y(async () => {
      if (!e.length) throw Error("Add images first");
      await $.pdf();
      const s = await PDFLib.PDFDocument.create();
      for (const r of e) {
        const i = await H(r), c = n("canvas");
        c.width = i.width, c.height = i.height;
        const l = c.getContext("2d");
        l.fillStyle = "#fff", l.fillRect(0, 0, c.width, c.height), l.drawImage(i, 0, 0);
        const d = await s.embedJpg(await (await A(c, "image/jpeg", 0.92)).arrayBuffer()), u = Math.min(1, 595 / d.width);
        s.addPage([d.width * u, d.height * u]).drawImage(d, { x: 0, y: 0, width: d.width * u, height: d.height * u });
      }
      b(new Blob([await s.save()]), "images.pdf");
    }), "pri"));
  } },
  /* ---------------- IMAGE ---------------- */
  { id: "image-editor", n: "Image Editor", c: "image", i: "🎨", d: "Rotate, flip and apply filters to an image.", run(o) {
    let e, t = 0, a = !1;
    const s = n("canvas", { style: "max-width:100%;border-radius:8px" }), r = () => {
      if (!e) return;
      const c = t % 2;
      s.width = c ? e.height : e.width, s.height = c ? e.width : e.height;
      const l = s.getContext("2d");
      l.save(), l.filter = i.value, l.translate(s.width / 2, s.height / 2), l.rotate(t * Math.PI / 2), a && l.scale(-1, 1), l.drawImage(e, -e.width / 2, -e.height / 2), l.restore();
    }, i = n("select", { onchange: r }, ...[["none", "No filter"], ["grayscale(1)", "Grayscale"], ["sepia(1)", "Sepia"], ["invert(1)", "Invert"], ["blur(3px)", "Blur"], ["brightness(1.3)", "Brighter"], ["contrast(1.4)", "High contrast"]].map(([c, l]) => n("option", { value: c }, l)));
    o.append(M("image/*", !1, (c) => y(async () => {
      e = await H(c[0]), t = 0, a = !1, r();
    })), n("div", { class: "row" }, p("⟲ 90°", () => {
      t = (t + 3) % 4, r();
    }), p("⟳ 90°", () => {
      t = (t + 1) % 4, r();
    }), p("Flip ↔", () => {
      a = !a, r();
    }), i, p("Save PNG", async () => {
      if (!e) return x("Choose an image first");
      b(await A(s, "image/png"), "edited.png");
    }, "pri")), s);
  } },
  { id: "image-to-base64", n: "Image to Base64", c: "image", i: "🔗", d: "Turn an image into a Base64 data URL.", run(o) {
    const e = n("textarea", { readOnly: !0 }), t = n("img", { style: "max-width:200px;border-radius:8px" });
    o.append(M("image/*", !1, (a) => y(async () => {
      e.value = await pe(a[0]), t.src = e.value;
    })), t, n("div", { class: "row" }, p("Copy data URL", () => D(e.value), "pri")), e);
  } },
  { id: "image-color-picker", n: "Image Color Picker", c: "image", i: "💧", d: "Click anywhere on an image to grab its color.", run(o) {
    const e = n("canvas", { style: "max-width:100%;cursor:crosshair;border-radius:8px" }), t = n("div", { class: "list" });
    e.onclick = (a) => {
      const s = e.getBoundingClientRect(), r = Math.floor((a.clientX - s.left) * e.width / s.width), i = Math.floor((a.clientY - s.top) * e.height / s.height), [c, l, d] = e.getContext("2d").getImageData(r, i, 1, 1).data, u = B(c, l, d);
      t.prepend(n("div", { class: "row" }, n("span", { style: `width:28px;height:28px;border-radius:8px;background:${u};border:1px solid var(--bd)` }), n("b", {}, u), n("span", { class: "mut" }, `rgb(${c}, ${l}, ${d})`), n("span", { class: "sp" }), p("Copy", () => D(u))));
    }, o.append(M("image/*", !1, (a) => y(async () => {
      const s = await H(a[0]);
      e.width = s.width, e.height = s.height, e.getContext("2d").drawImage(s, 0, 0);
    })), e, t);
  } },
  /* ---------------- DEVELOPER ---------------- */
  { id: "url-encoder", n: "URL Encoder", c: "dev", i: "🌐", d: "Encode and decode URLs and query strings.", run: (o) => L(o, { Encode: encodeURIComponent, Decode: decodeURIComponent, "Encode full URL": encodeURI }) },
  { id: "html-entities", n: "HTML Entities", c: "dev", i: "🏷️", d: "Escape and unescape HTML characters.", run: (o) => L(o, { Escape: (e) => e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;"), Unescape: (e) => new DOMParser().parseFromString(e, "text/html").documentElement.textContent }) },
  { id: "hash-generator", n: "Hash Generator", c: "dev", i: "#️⃣", d: "SHA-1, SHA-256, SHA-384 and SHA-512 hashes.", run: (o) => L(o, Object.fromEntries(["SHA-256", "SHA-1", "SHA-384", "SHA-512"].map((e) => [e, async (t) => [...new Uint8Array(await crypto.subtle.digest(e, new TextEncoder().encode(t)))].map((a) => a.toString(16).padStart(2, "0")).join("")]))) },
  { id: "jwt-decoder", n: "JWT Decoder", c: "dev", i: "🎫", d: "Decode a JWT header and payload (no upload).", run: (o) => L(o, { Decode: (e) => {
    const t = e.trim().split(".");
    if (t.length < 2) throw Error("Not a JWT");
    const a = JSON.parse(Q(t[0])), s = JSON.parse(Q(t[1]));
    let r = `HEADER
` + JSON.stringify(a, null, 2) + `

PAYLOAD
` + JSON.stringify(s, null, 2);
    for (const i of ["iat", "exp", "nbf"]) s[i] && (r += `
${i}: ${new Date(s[i] * 1e3).toLocaleString()}`);
    return r + `

(Signature is not verified.)`;
  } }, "Paste a JWT…") },
  { id: "json-csv", n: "JSON ⇄ CSV", c: "dev", i: "📊", d: "Convert between JSON arrays and CSV.", run: (o) => L(o, {
    "JSON → CSV": (e) => {
      const t = JSON.parse(e);
      if (!Array.isArray(t)) throw Error("Need a JSON array of objects");
      const a = [...new Set(t.flatMap((r) => Object.keys(r)))], s = (r) => (r = r == null ? "" : typeof r == "object" ? JSON.stringify(r) : String(r), /[",\n]/.test(r) ? '"' + r.replace(/"/g, '""') + '"' : r);
      return [a.map(s).join(","), ...t.map((r) => a.map((i) => s(r[i])).join(","))].join(`
`);
    },
    "CSV → JSON": (e) => {
      const [t, ...a] = ue(e.trim());
      return JSON.stringify(a.map((s) => Object.fromEntries(t.map((r, i) => [r, s[i] ?? ""]))), null, 2);
    }
  }) },
  { id: "regex-tester", n: "Regex Tester", c: "dev", i: "🔍", d: "Test regular expressions with live matches.", run(o) {
    const e = n("input", { placeholder: "pattern", style: "flex:1" }), t = n("input", { value: "g", style: "width:70px" }), a = n("textarea", { placeholder: "Test text…" }), s = n("div", { class: "list" }), r = () => {
      if (s.replaceChildren(), !!e.value)
        try {
          const i = new RegExp(e.value, t.value.includes("g") ? t.value : t.value + "g"), c = [...a.value.matchAll(i)].slice(0, 300);
          s.append(n("div", { class: "mut" }, c.length + " match(es)"), ...c.map((l, d) => n("div", { class: "row" }, n("b", {}, `#${d + 1}`), n("code", {}, JSON.stringify(l[0])), n("span", { class: "mut" }, "@" + l.index + (l.length > 1 ? " groups: " + l.slice(1).map((u) => JSON.stringify(u)).join(", ") : "")))));
        } catch (i) {
          s.append(n("div", { style: "color:var(--bad)" }, i.message));
        }
    };
    [e, t, a].forEach((i) => i.oninput = r), o.append(n("div", { class: "row" }, "/", e, "/", t), a, s);
  } },
  { id: "timestamp", n: "Timestamp Converter", c: "dev", i: "🕒", d: "Convert Unix timestamps and dates.", run: (o) => k(o, [["Unix (s or ms)", "number", Math.floor(Date.now() / 1e3)], ["Date (YYYY-MM-DD HH:MM)", "text", (/* @__PURE__ */ new Date()).toISOString().slice(0, 16).replace("T", " ")]], (e, t) => {
    const a = +e > 1e12 ? +e : +e * 1e3, s = new Date(a), r = new Date(t.replace(" ", "T"));
    return [["UTC", s.toUTCString()], ["ISO", s.toISOString()], ["Local", s.toLocaleString()], ["Date → Unix (s)", isNaN(r) ? "invalid" : Math.floor(r / 1e3)]];
  }) },
  { id: "number-base", n: "Number Base Converter", c: "dev", i: "🔟", d: "Binary, octal, decimal, hex and any base to 36.", run: (o) => k(o, [["Number", "text", "255"], ["From base (2–36)", "number", 10]], (e, t) => {
    if (t = +t, t < 2 || t > 36) throw Error("Base must be 2–36");
    let a = 0n;
    for (const s of e.trim().toLowerCase()) {
      const r = parseInt(s, 36);
      if (isNaN(r) || r >= t) throw Error("Invalid digit '" + s + "'");
      a = a * BigInt(t) + BigInt(r);
    }
    return [["Binary", a.toString(2)], ["Octal", a.toString(8)], ["Decimal", a.toString(10)], ["Hex", a.toString(16).toUpperCase()]];
  }) },
  { id: "color-converter", n: "Color Converter", c: "dev", i: "🌈", d: "Convert HEX, RGB and HSL colors.", run: (o) => k(o, [["Color (#hex or rgb())", "text", "#8b7cff"]], (e) => {
    e = e.trim();
    let t, a, s, r;
    if (r = e.match(/^#?([\da-f]{3}|[\da-f]{6})$/i)) {
      let d = r[1];
      d.length === 3 && (d = [...d].map((u) => u + u).join("")), [t, a, s] = [0, 2, 4].map((u) => parseInt(d.slice(u, u + 2), 16));
    } else if (r = e.match(/^rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)$/i)) [t, a, s] = r.slice(1).map(Number);
    else throw Error("Use #rrggbb or rgb(r,g,b)");
    const [i, c, l] = de(t, a, s);
    return [["Preview", n("span", { style: `display:inline-block;width:70px;height:26px;border-radius:8px;background:${B(t, a, s)};border:1px solid var(--bd)` })], ["HEX", B(t, a, s)], ["RGB", `rgb(${t}, ${a}, ${s})`], ["HSL", `hsl(${i}, ${c}%, ${l}%)`]];
  }) },
  { id: "markdown-preview", n: "Markdown Preview", c: "dev", i: "Ⓜ️", d: "Write Markdown and see it rendered live.", run(o) {
    const e = n("textarea", { value: `# Hello

Write **bold**, *italic*, \`code\`, and [links](https://example.com).

- item one
- item two` }), t = n("div", { class: "panel", style: "max-width:none" });
    e.oninput = () => t.innerHTML = me(e.value), e.oninput(), o.append(e, t);
  } },
  /* ---------------- TEXT ---------------- */
  { id: "text-diff", n: "Text Diff", c: "text", i: "🆚", d: "Compare two texts line by line.", run(o) {
    const e = n("textarea", { placeholder: "Original" }), t = n("textarea", { placeholder: "Changed" }), a = n("div", { class: "list", style: "font:13px ui-monospace,monospace" });
    o.append(e, t, p("Compare", () => {
      const s = e.value.split(`
`), r = t.value.split(`
`);
      if (s.length > 2500 || r.length > 2500) return x("Too many lines (max 2500)");
      const i = he(s, r);
      a.replaceChildren(n("div", { class: "mut" }, `${i.filter((c) => c[0] === "+").length} added · ${i.filter((c) => c[0] === "-").length} removed`), ...i.map(([c, l]) => n("div", { style: `white-space:pre-wrap;padding:2px 8px;border-radius:6px;background:${c === "+" ? "rgba(66,211,146,.15)" : c === "-" ? "rgba(255,107,129,.15)" : "transparent"}` }, c + " " + l)));
    }, "pri"), a);
  } },
  { id: "line-tools", n: "Line Tools", c: "text", i: "📃", d: "Sort, dedupe, shuffle and clean lines of text.", run: (o) => L(o, {
    "Sort A→Z": (e) => e.split(`
`).sort((t, a) => t.localeCompare(a)).join(`
`),
    "Sort Z→A": (e) => e.split(`
`).sort((t, a) => a.localeCompare(t)).join(`
`),
    "By length": (e) => e.split(`
`).sort((t, a) => t.length - a.length).join(`
`),
    "Remove duplicates": (e) => [...new Set(e.split(`
`))].join(`
`),
    "Remove empty": (e) => e.split(`
`).filter((t) => t.trim()).join(`
`),
    "Trim lines": (e) => e.split(`
`).map((t) => t.trim()).join(`
`),
    Reverse: (e) => e.split(`
`).reverse().join(`
`),
    Shuffle: (e) => {
      const t = e.split(`
`);
      for (let a = t.length - 1; a > 0; a--) {
        const s = S(a + 1);
        [t[a], t[s]] = [t[s], t[a]];
      }
      return t.join(`
`);
    },
    "Number lines": (e) => e.split(`
`).map((t, a) => `${a + 1}. ${t}`).join(`
`)
  }) },
  { id: "find-replace", n: "Find & Replace", c: "text", i: "🔁", d: "Find and replace text, with regex support.", run(o) {
    const e = n("textarea"), t = n("input", { placeholder: "Find" }), a = n("input", { placeholder: "Replace with" }), s = n("input", { type: "checkbox" }), r = n("input", { type: "checkbox" }), i = n("span", { class: "mut" });
    o.append(e, n("div", { class: "row" }, t, a), n("div", { class: "row" }, n("label", {}, s, " Regex"), n("label", {}, r, " Match case"), p("Replace all", () => {
      try {
        if (!t.value) return;
        const c = new RegExp(s.checked ? t.value : t.value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g" + (r.checked ? "" : "i"));
        let l = 0;
        e.value = e.value.replace(c, (...d) => (l++, a.value)), i.textContent = l + " replaced";
      } catch (c) {
        x("Error: " + c.message);
      }
    }, "pri"), i));
  } },
  { id: "text-cleaner", n: "Text Cleaner & Slug", c: "text", i: "🧼", d: "Slugify, strip HTML, fix spaces, reverse text.", run: (o) => L(o, {
    Slugify: (e) => e.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, ""),
    "Fix spaces": (e) => e.replace(/[ \t]+/g, " ").replace(/\n{3,}/g, `

`).trim(),
    "Strip HTML": (e) => new DOMParser().parseFromString(e, "text/html").body.textContent,
    "Reverse text": (e) => [...e].reverse().join(""),
    "Remove accents": (e) => e.normalize("NFD").replace(/[\u0300-\u036f]/g, "")
  }) },
  { id: "morse-code", n: "Morse Code", c: "text", i: "📡", d: "Translate text to Morse code and back.", run: (o) => L(o, { "Text → Morse": (e) => [...e.toLowerCase()].map((t) => t === " " ? "/" : G[t] || "").filter(Boolean).join(" "), "Morse → Text": (e) => e.trim().split(/\s+/).map((t) => t === "/" ? " " : Object.keys(G).find((a) => G[a] === t) || "?").join("") }, "Text, or Morse using . - and / for spaces") },
  { id: "text-to-speech", n: "Text to Speech", c: "text", i: "🔊", d: "Read text aloud with your device's voices.", run(o) {
    const e = n("textarea", { placeholder: "Text to read…" }), t = n("select"), a = n("input", { type: "range", min: 0.5, max: 2, step: 0.1, value: 1 }), s = window.speechSynthesis;
    if (!s) {
      o.append(n("p", {}, "Speech isn't supported in this browser."));
      return;
    }
    const r = () => t.replaceChildren(...s.getVoices().map((i, c) => n("option", { value: c }, i.name + " (" + i.lang + ")")));
    r(), s.onvoiceschanged = r, o.append(e, n("div", { class: "row" }, t, n("label", {}, "Speed"), a, p("Speak", () => {
      s.cancel();
      const i = new SpeechSynthesisUtterance(e.value);
      i.voice = s.getVoices()[+t.value] || null, i.rate = +a.value, s.speak(i);
    }, "pri"), p("Stop", () => s.cancel())));
  } },
  { id: "lorem-ipsum", n: "Lorem Ipsum", c: "gen", i: "📜", d: "Generate placeholder paragraphs.", run(o) {
    const e = n("input", { type: "number", min: 1, max: 30, value: 3, style: "width:80px" }), t = n("textarea", { readOnly: !0, style: "min-height:260px" }), a = () => {
      t.value = Array.from({ length: Math.min(30, Math.max(1, +e.value || 1)) }, () => {
        const s = Array.from({ length: 40 + S(40) }, () => K[S(K.length)]).join(" ");
        return s[0].toUpperCase() + s.slice(1) + ".";
      }).join(`

`);
    };
    a(), o.append(n("div", { class: "row" }, n("label", {}, "Paragraphs"), e, p("Generate", a, "pri"), p("Copy", () => D(t.value))), t);
  } },
  /* ---------------- CALCULATORS ---------------- */
  { id: "age-calculator", n: "Age Calculator", c: "calc", i: "🎂", d: "Exact age and days to your next birthday.", run: (o) => k(o, [["Date of birth", "date", ""]], (e) => {
    if (!e) throw Error("Pick a date of birth");
    const t = new Date(e), a = /* @__PURE__ */ new Date();
    let s = a.getFullYear() - t.getFullYear(), r = a.getMonth() - t.getMonth(), i = a.getDate() - t.getDate();
    i < 0 && (r--, i += new Date(a.getFullYear(), a.getMonth(), 0).getDate()), r < 0 && (s--, r += 12);
    const c = new Date(a.getFullYear(), a.getMonth(), a.getDate()), l = new Date(a.getFullYear(), t.getMonth(), t.getDate());
    return l < c && l.setFullYear(a.getFullYear() + 1), [["Age", `${s}y ${r}m ${i}d`], ["Total days", Math.floor((c - t) / 864e5).toLocaleString()], ["Next birthday in", Math.round((l - c) / 864e5) + " days"]];
  }) },
  { id: "bmi-calculator", n: "BMI Calculator", c: "calc", i: "⚖️", d: "Body mass index from height and weight.", run: (o) => k(o, [["Height (cm)", "number", 165], ["Weight (kg)", "number", 55]], (e, t) => {
    const a = t / (e / 100) ** 2;
    if (!isFinite(a)) throw Error("Enter height and weight");
    return [["BMI", a.toFixed(1)], ["Adult category", a < 18.5 ? "Underweight" : a < 25 ? "Normal" : a < 30 ? "Overweight" : "Obese"], ["Note", "Under 18? Use BMI-for-age charts"]];
  }) },
  { id: "percentage-calculator", n: "Percentage Calculator", c: "calc", i: "％", d: "Percent of, percent change and more.", run: (o) => k(o, [["X", "number", 20], ["Y", "number", 200]], (e, t) => (e = +e, t = +t, [[`${e}% of ${t}`, j(e * t / 100)], [`${e} is what % of ${t}`, j(e / t * 100) + "%"], [`Change ${e} → ${t}`, j((t - e) / e * 100) + "%"]])) },
  { id: "marks-percentage", n: "Marks & Grade", c: "calc", i: "📝", d: "Percentage and CBSE-style grade from marks.", run: (o) => k(o, [["Marks obtained", "number", 432], ["Total marks", "number", 500]], (e, t) => {
    const a = e / t * 100;
    if (!isFinite(a)) throw Error("Enter marks");
    return [["Percentage", a.toFixed(2) + "%"], ["Grade", a >= 91 ? "A1" : a >= 81 ? "A2" : a >= 71 ? "B1" : a >= 61 ? "B2" : a >= 51 ? "C1" : a >= 41 ? "C2" : a >= 33 ? "D" : "E"]];
  }) },
  { id: "emi-calculator", n: "Loan EMI Calculator", c: "calc", i: "🏦", d: "Monthly EMI, total interest and payment.", run: (o) => k(o, [["Loan amount", "number", 5e5], ["Interest rate (% / year)", "number", 9], ["Tenure (years)", "number", 5]], (e, t, a) => {
    e = +e;
    const s = t / 1200, r = a * 12, i = s ? e * s * (1 + s) ** r / ((1 + s) ** r - 1) : e / r;
    if (!isFinite(i)) throw Error("Check the numbers");
    return [["Monthly EMI", i.toFixed(2)], ["Total interest", (i * r - e).toFixed(2)], ["Total payment", (i * r).toFixed(2)]];
  }) },
  { id: "discount-gst", n: "Discount & GST", c: "calc", i: "🏷️", d: "Final price after discount and tax.", run: (o) => k(o, [["Price", "number", 1e3], ["Discount %", "number", 10], ["GST / tax %", "number", 18]], (e, t, a) => {
    const s = e * (1 - t / 100), r = s * a / 100;
    return [["After discount", s.toFixed(2)], ["Tax amount", r.toFixed(2)], ["Final price", (s + r).toFixed(2)], ["You save", (e - s).toFixed(2)]];
  }) },
  { id: "date-difference", n: "Date Difference", c: "calc", i: "📅", d: "Days between two dates.", run: (o) => k(o, [["From", "date", (/* @__PURE__ */ new Date()).toISOString().slice(0, 10)], ["To", "date", ""]], (e, t) => {
    if (!e || !t) throw Error("Pick both dates");
    const a = Math.round((new Date(t) - new Date(e)) / 864e5);
    return [["Days", a.toLocaleString()], ["Weeks", (a / 7).toFixed(1)], ["Months (approx)", (a / 30.44).toFixed(1)], ["Years (approx)", (a / 365.25).toFixed(2)]];
  }) },
  { id: "scientific-calculator", n: "Scientific Calculator", c: "calc", i: "🧮", d: "Type an expression: sin, cos, sqrt, log, π and more.", run(o) {
    const e = n("input", { placeholder: "e.g. sqrt(144) + 2^5 * sin(pi/2)", style: "width:100%;font-size:18px" }), t = n("div", { class: "big", style: "font-size:40px" }, "="), a = n("div", { class: "list" }), s = ["sin", "cos", "tan", "asin", "acos", "atan", "sqrt", "cbrt", "log", "ln", "abs", "pi", "e", "exp", "floor", "ceil", "round", "min", "max", "pow"], r = () => {
      const i = e.value.trim();
      if (i)
        try {
          if (!/^[\d\s+\-*/().,^%a-z]+$/i.test(i)) throw Error("bad characters");
          for (const d of i.match(/[a-z]+/gi) || []) if (!s.includes(d.toLowerCase())) throw Error("unknown: " + d);
          const c = i.replace(/\^/g, "**").replace(/[a-z]+/gi, (d) => (d = d.toLowerCase(), d === "pi" ? "Math.PI" : d === "e" ? "Math.E" : d === "ln" ? "Math.log" : d === "log" ? "Math.log10" : "Math." + d)), l = Function('"use strict";return(' + c + ")")();
          if (typeof l != "number" || !isFinite(l)) throw Error("not a number");
          t.textContent = "= " + j(l), a.prepend(n("div", { class: "row" }, n("code", {}, i), n("b", {}, "= " + j(l))));
        } catch (c) {
          t.textContent = "⚠ " + c.message;
        }
    };
    e.onkeydown = (i) => {
      i.key === "Enter" && r();
    }, o.append(e, n("div", { class: "row" }, p("Calculate", r, "pri"), n("span", { class: "mut" }, "ln = natural log, log = base 10, ^ = power")), t, a);
  } },
  /* ---------------- CONVERTERS ---------------- */
  { id: "unit-converter", n: "Unit Converter", c: "conv", i: "📏", d: "Length, mass, temperature, speed, data and more.", run(o) {
    const e = n("select", {}, ...Object.keys(J).map((l) => n("option", {}, l))), t = n("select"), a = n("select"), s = n("input", { type: "number", value: 1, step: "any" }), r = n("div", { class: "big", style: "font-size:34px" }), i = () => {
      const l = J[e.value], d = +s.value;
      e.value === "Temperature" ? r.textContent = j(we(d, t.value, a.value)) + " " + a.value : r.textContent = j(d * l[t.value] / l[a.value]) + " " + a.value;
    }, c = () => {
      const l = Object.keys(J[e.value]);
      t.replaceChildren(...l.map((d) => n("option", {}, d))), a.replaceChildren(...l.map((d, u) => n("option", { selected: u === 1 }, d))), i();
    };
    e.onchange = c, [t, a, s].forEach((l) => {
      l.oninput = i, l.onchange = i;
    }), o.append(e, n("div", { class: "row" }, s, t, "→", a, p("⇄", () => {
      [t.value, a.value] = [a.value, t.value], i();
    })), r), c();
  } },
  { id: "roman-numerals", n: "Roman Numerals", c: "conv", i: "🏛️", d: "Convert numbers to Roman numerals and back.", run: (o) => k(o, [["Number or Roman", "text", "2026"]], (e) => {
    e = e.trim().toUpperCase();
    const t = [[1e3, "M"], [900, "CM"], [500, "D"], [400, "CD"], [100, "C"], [90, "XC"], [50, "L"], [40, "XL"], [10, "X"], [9, "IX"], [5, "V"], [4, "IV"], [1, "I"]];
    if (/^\d+$/.test(e)) {
      let r = +e;
      if (r < 1 || r > 3999) throw Error("Use 1–3999");
      let i = "";
      for (const [c, l] of t) for (; r >= c; )
        i += l, r -= c;
      return [["Roman", i]];
    }
    if (!/^[MDCLXVI]+$/.test(e)) throw Error("Enter digits or a Roman numeral");
    let a = 0, s = 0;
    for (const [r, i] of t) for (; e.startsWith(i, s); )
      a += r, s += i.length;
    if (s !== e.length) throw Error("Invalid Roman numeral");
    return [["Number", a]];
  }) },
  { id: "number-to-words", n: "Number to Words", c: "conv", i: "🔡", d: "Numbers in words, Indian system (lakh, crore).", run: (o) => k(o, [["Number", "number", 1234567]], (e) => {
    const t = Math.floor(+e);
    if (!isFinite(t) || t < 0 || t > 1e15) throw Error("Use 0 to 10^15");
    return [["In words", ne(t)], ["Indian grouping", t.toLocaleString("en-IN")], ["International", t.toLocaleString("en-US")]];
  }) },
  /* ---------------- PRODUCTIVITY ---------------- */
  { id: "stopwatch", n: "Stopwatch", c: "prod", i: "⏱️", d: "Stopwatch with lap times.", run(o) {
    let e = 0, t = 0, a = null;
    const s = n("div", { class: "big" }), r = n("div", { class: "list" }), i = (d) => `${String(Math.floor(d / 6e4)).padStart(2, "0")}:${String(Math.floor(d / 1e3) % 60).padStart(2, "0")}.${String(Math.floor(d / 10) % 100).padStart(2, "0")}`, c = () => t + (a ? performance.now() - e : 0), l = () => s.textContent = i(c());
    o.append(s, n("div", { class: "row", style: "justify-content:center" }, p("Start / Stop", () => {
      a ? (t = c(), clearInterval(a), a = null) : (e = performance.now(), a = setInterval(l, 30)), l();
    }, "pri"), p("Lap", () => {
      a && r.prepend(n("div", { class: "row" }, "Lap " + (r.children.length + 1), n("b", {}, i(c()))));
    }), p("Reset", () => {
      clearInterval(a), a = null, t = 0, r.replaceChildren(), l();
    })), r), l();
  } },
  { id: "countdown-timer", n: "Countdown Timer", c: "prod", i: "⏳", d: "Count down from any time with an alarm.", run(o) {
    const e = n("input", { type: "number", min: 0, value: 10, style: "width:80px" }), t = n("input", { type: "number", min: 0, max: 59, value: 0, style: "width:80px" }), a = n("div", { class: "big" });
    let s = null, r = 0;
    const i = (c) => {
      const l = Math.max(0, Math.ceil(c / 1e3));
      a.textContent = `${String(Math.floor(l / 60)).padStart(2, "0")}:${String(l % 60).padStart(2, "0")}`;
    };
    i((+e.value * 60 + +t.value) * 1e3), o.append(n("div", { class: "row", style: "justify-content:center" }, e, "min", t, "sec"), a, n("div", { class: "row", style: "justify-content:center" }, p("Start", () => {
      clearInterval(s), r = Date.now() + (+e.value * 60 + +t.value) * 1e3, s = setInterval(() => {
        const c = r - Date.now();
        i(c), c <= 0 && (clearInterval(s), le(), x("⏰ Time's up!", 5e3));
      }, 200);
    }, "pri"), p("Stop", () => clearInterval(s))));
  } },
  { id: "todo-list", n: "To-Do List", c: "prod", i: "✅", d: "Simple task list saved in your browser.", run(o) {
    let e = P.g("st-todo", []);
    const t = () => P.s("st-todo", e), a = n("div", { class: "list" }), s = n("input", { placeholder: "Add a task and press Enter", style: "flex:1" }), r = () => a.replaceChildren(...e.map((c, l) => n("div", { class: "row" }, n("input", { type: "checkbox", checked: c.d, onchange: (d) => {
      c.d = d.target.checked, t(), r();
    } }), n("span", { style: c.d ? "text-decoration:line-through;opacity:.5" : "" }, c.t), n("span", { class: "sp" }), p("✕", () => {
      e.splice(l, 1), t(), r();
    })))), i = () => {
      s.value.trim() && (e.push({ t: s.value.trim(), d: !1 }), s.value = "", t(), r());
    };
    s.onkeydown = (c) => c.key === "Enter" && i(), o.append(n("div", { class: "row" }, s, p("Add", i, "pri"), p("Clear done", () => {
      e = e.filter((c) => !c.d), t(), r();
    })), a), r();
  } },
  { id: "quick-notes", n: "Quick Notes", c: "prod", i: "🗒️", d: "Auto-saving notepad that lives in your browser.", run(o) {
    const e = n("textarea", { style: "min-height:320px", value: P.g("st-notes", "") }), t = n("span", { class: "mut" });
    e.oninput = () => {
      P.s("st-notes", e.value), t.textContent = "Saved · " + e.value.length + " chars";
    }, o.append(e, n("div", { class: "row" }, p("Save .txt", () => b(e.value || " ", "notes.txt"), "pri"), p("Copy", () => D(e.value)), t));
  } },
  { id: "random-picker", n: "Dice, Coin & Random", c: "prod", i: "🎲", d: "Roll dice, flip a coin, pick a number or a name.", run(o) {
    const e = n("div", { class: "big", style: "font-size:44px" }, "🎲"), t = n("select", {}, ...[4, 6, 8, 10, 12, 20].map((l) => n("option", { value: l, selected: l === 6 }, "d" + l))), a = n("input", { type: "number", min: 1, max: 10, value: 1, style: "width:70px" }), s = n("input", { type: "number", value: 1, style: "width:90px" }), r = n("input", { type: "number", value: 100, style: "width:90px" }), i = n("textarea", { style: "min-height:90px", placeholder: "One name or option per line…" }), c = () => i.value.split(`
`).map((l) => l.trim()).filter(Boolean);
    o.append(
      e,
      n("div", { class: "row" }, a, t, p("Roll", () => {
        const l = Math.min(10, +a.value || 1), d = Array.from({ length: l }, () => 1 + S(+t.value));
        e.textContent = d.join(" + ") + (l > 1 ? " = " + d.reduce((u, h) => u + h) : "");
      }, "pri"), p("Flip coin", () => e.textContent = S(2) ? "Heads 🪙" : "Tails 🪙")),
      n("div", { class: "row" }, s, "to", r, p("Random number", () => {
        const l = Math.ceil(+s.value), d = Math.floor(+r.value);
        if (d < l) return x("Max must be ≥ min");
        e.textContent = l + S(d - l + 1);
      })),
      i,
      n("div", { class: "row" }, p("Pick one", () => {
        const l = c();
        l.length && (e.textContent = l[S(l.length)]);
      }), p("Shuffle list", () => {
        const l = c();
        for (let d = l.length - 1; d > 0; d--) {
          const u = S(d + 1);
          [l[d], l[u]] = [l[u], l[d]];
        }
        i.value = l.join(`
`);
      }))
    );
  } },
  /* ---------------- EDUCATION ---------------- */
  { id: "math-quiz", n: "Math Quiz", c: "edu", i: "➗", d: "10 quick questions to sharpen mental math.", run(o) {
    const e = n("select", {}, ...["+", "−", "×", "÷"].map((h) => n("option", {}, h))), t = n("select", {}, n("option", { value: 10 }, "Easy (to 10)"), n("option", { value: 20, selected: !0 }, "Medium (to 20)"), n("option", { value: 100 }, "Hard (to 100)")), a = n("div", { class: "panel" });
    let s, r, i, c;
    const l = () => {
      const h = +t.value, m = 1 + S(h), g = 1 + S(h), v = e.value;
      i = v === "+" ? [m, g, m + g] : v === "−" ? [Math.max(m, g), Math.min(m, g), Math.abs(m - g)] : v === "×" ? [m, g, m * g] : [m * g, m, g];
    }, d = () => {
      if (s > 10) {
        a.replaceChildren(n("div", { class: "big" }, `${r}/10`), n("p", { class: "mut", style: "text-align:center" }, `Finished in ${Math.round((Date.now() - c) / 1e3)}s`), p("Play again", u, "pri"));
        return;
      }
      const h = n("input", { type: "number", style: "font-size:22px;width:140px", autofocus: !0 }), m = () => {
        h.value !== "" && (+h.value === i[2] ? (r++, x("✓ Correct", 700)) : x("✗ It was " + i[2], 1400), s++, l(), d());
      };
      h.onkeydown = (g) => g.key === "Enter" && m(), a.replaceChildren(n("div", { class: "mut" }, `Question ${s} of 10 · score ${r}`), n("div", { class: "big", style: "font-size:48px" }, `${i[0]} ${e.value} ${i[1]} = ?`), n("div", { class: "row", style: "justify-content:center" }, h, p("Submit", m, "pri"))), setTimeout(() => h.focus(), 30);
    }, u = () => {
      s = 1, r = 0, c = Date.now(), l(), d();
    };
    o.append(n("div", { class: "row" }, e, t, p("Start", u, "pri")), a);
  } },
  { id: "typing-test", n: "Typing Test", c: "edu", i: "⌨️", d: "Measure your typing speed and accuracy.", run(o) {
    let e = "", t = 0, a = !1;
    const s = n("div", { class: "panel", style: "font:20px/1.7 ui-monospace,monospace;max-width:none" }), r = n("textarea", { placeholder: "Start typing here…", style: "min-height:90px;font-family:inherit" }), i = n("div", { class: "stats" }), c = () => {
      e = Array.from({ length: 2 }, () => ee[S(ee.length)]).join(" "), r.value = "", t = 0, a = !1, r.disabled = !1, l(), i.replaceChildren();
    }, l = () => s.replaceChildren(...[...e].map((d, u) => n("span", { style: u < r.value.length ? r.value[u] === d ? "color:var(--ok)" : "color:var(--bad);text-decoration:underline" : "opacity:.6" }, d)));
    r.oninput = () => {
      if (!a && (t || (t = Date.now()), l(), r.value.length >= e.length)) {
        a = !0, r.disabled = !0;
        const d = (Date.now() - t) / 6e4, u = [...e].filter((h, m) => r.value[m] === h).length;
        i.replaceChildren(...[["WPM", Math.round(e.length / 5 / d)], ["Accuracy", Math.round(u / e.length * 100) + "%"], ["Time", (d * 60).toFixed(1) + "s"]].map(([h, m]) => n("div", {}, n("b", {}, m), h)));
      }
    }, o.append(s, r, i, p("New text", c, "pri")), c();
  } },
  { id: "times-tables", n: "Times Tables", c: "edu", i: "✖️", d: "Multiplication tables for any number.", run: (o) => k(o, [["Table of", "number", 7]], (e) => Array.from({ length: 12 }, (t, a) => [`${e} × ${a + 1}`, +e * (a + 1)])) },
  /* ---------------- GENERATORS ---------------- */
  { id: "color-palette", n: "Color Palette Generator", c: "gen", i: "🎯", d: "Generate harmonious palettes — click to copy.", run(o) {
    const e = n("div", { class: "grid", style: "grid-template-columns:repeat(auto-fit,minmax(110px,1fr))" }), t = () => {
      const a = S(360), s = 55 + S(35), r = [a, (a + 30) % 360, (a + 180) % 360, (a + 210) % 360, (a + 90) % 360];
      e.replaceChildren(...r.map((i, c) => {
        const l = B(...ce(i, s, 40 + c * 8));
        return n("div", { class: "card", style: `background:${l};border:0;height:120px;display:flex;align-items:flex-end;color:#fff;text-shadow:0 1px 3px #0008`, onclick: () => D(l) }, n("b", {}, l));
      }));
    };
    t(), o.append(p("Generate new palette", t, "pri"), e);
  } },
  { id: "gradient-generator", n: "CSS Gradient Generator", c: "gen", i: "🌅", d: "Build a CSS gradient and copy the code.", run(o) {
    const e = n("input", { type: "color", value: "#8b7cff" }), t = n("input", { type: "color", value: "#42d392" }), a = n("input", { type: "range", min: 0, max: 360, value: 135 }), s = n("select", {}, n("option", { value: "linear" }, "Linear"), n("option", { value: "radial" }, "Radial")), r = n("div", { style: "height:160px;border-radius:14px" }), i = n("input", { readOnly: !0, style: "width:100%" }), c = () => {
      const l = s.value === "linear" ? `linear-gradient(${a.value}deg, ${e.value}, ${t.value})` : `radial-gradient(circle, ${e.value}, ${t.value})`;
      r.style.background = l, i.value = `background: ${l};`;
    };
    [e, t, a, s].forEach((l) => {
      l.oninput = c;
    }), c(), o.append(r, n("div", { class: "row" }, e, t, s, n("label", {}, "Angle"), a), i, p("Copy CSS", () => D(i.value), "pri"));
  } }
], re = [...ie, ...ye], I = window.__PAGE__ || {}, oe = I.root || "./", Y = Object.fromEntries(re.map((o) => [o.id, o]));
let R = P.g("st-fav", []), q = P.g("st-rec", []);
const te = N("#th");
te && (te.onclick = () => {
  const o = document.documentElement.dataset.theme === "light" ? "dark" : "light";
  document.documentElement.dataset.theme = o;
  try {
    localStorage.setItem("st-theme", o);
  } catch {
  }
});
const se = (o) => {
  const e = o.dataset.id, t = n("button", { class: "star" + (R.includes(e) ? " on" : ""), title: "Favorite", onclick: (a) => {
    a.preventDefault(), a.stopPropagation(), R = R.includes(e) ? R.filter((s) => s !== e) : [...R, e], P.s("st-fav", R), t.classList.toggle("on");
  } }, "★");
  o.append(t);
}, xe = (o) => {
  const e = n("a", { class: "card", "data-id": o.id, href: oe + o.id + "/" }, n("div", { class: "ic" }, o.i), n("h3", {}, o.n), n("p", {}, o.d));
  return se(e), e;
};
document.querySelectorAll("a.card[data-id]").forEach(se);
if (I.type === "home") {
  const o = (t, a) => {
    const s = a.map((r) => Y[r]).filter(Boolean).slice(0, 8);
    return s.length ? n("section", { class: "hero-sec" }, n("h2", {}, t), n("div", { class: "grid" }, s.map(xe))) : null;
  }, e = N("#view .hero-sec");
  [o("⭐ Your favorites", R), o("🕘 Recently used", q.slice(0, 4))].filter(Boolean).reverse().forEach((t) => e.before(t));
}
if (I.type === "tool" && Y[I.id]) {
  q = [I.id, ...q.filter((e) => e !== I.id)].slice(0, 12), P.s("st-rec", q);
  const o = N("#tool-mount");
  o.replaceChildren();
  try {
    Y[I.id].run(o);
  } catch (e) {
    o.textContent = "Sorry, this tool failed to start: " + e.message;
  }
}
const T = N("#q"), F = N("#sr");
T && F && (T.oninput = () => {
  const o = T.value.toLowerCase().trim();
  if (F.replaceChildren(), !o) {
    F.style.display = "none";
    return;
  }
  const e = re.filter((t) => (t.n + " " + t.d + " " + t.id).toLowerCase().includes(o)).slice(0, 8);
  F.style.display = "block", F.append(...e.length ? e.map((t) => n("a", { href: oe + t.id + "/" }, t.i + "  " + t.n)) : [n("div", { class: "mut", style: "padding:10px 14px" }, "No tools found")]);
}, T.onkeydown = (o) => {
  var e;
  o.key === "Escape" && (T.value = "", T.oninput()), o.key === "Enter" && ((e = F.firstChild) != null && e.href) && (location.href = F.firstChild.href);
}, addEventListener("keydown", (o) => {
  o.key === "/" && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName) && (o.preventDefault(), T.focus());
}), document.addEventListener("click", (o) => {
  !F.contains(o.target) && o.target !== T && (F.style.display = "none");
}));
