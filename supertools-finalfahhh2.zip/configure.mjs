#!/usr/bin/env node
// Fills in your real details across the built website. No installs needed — just Node.js.
//
//   node configure.mjs <website-folder> --domain https://supertools.in --email you@gmail.com [--adsense ca-pub-1234567890] [--donate https://your-donate-link]
//
// Run it on a fresh copy of the website folder (it replaces placeholders, so run once per fresh build).
import { readdirSync, readFileSync, writeFileSync, statSync } from 'node:fs'
import { join } from 'node:path'

const a = process.argv.slice(2), dir = a[0]
const get = k => { const i = a.indexOf('--' + k); return i > -1 ? a[i + 1] : '' }
if (!dir || dir.startsWith('--') || !get('domain')) { console.log('Usage: node configure.mjs <website-folder> --domain https://yourdomain.com [--email you@mail.com] [--adsense ca-pub-XXXX] [--donate URL]'); process.exit(1) }

let domain = get('domain').replace(/\/+$/, ''); if (!/^https?:\/\//.test(domain)) domain = 'https://' + domain
const email = get('email') || 'hello@' + domain.replace(/^https?:\/\//, '').replace(/^www\./, ''), ads = get('adsense'), donate = get('donate')
const adTag = ads ? `<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${ads}" crossorigin="anonymous"></script>` : ''

let n = 0
const walk = d => { for (const f of readdirSync(d)) { const p = join(d, f); if (statSync(p).isDirectory()) walk(p); else if (/\.(html|xml|txt)$/.test(f)) fix(p) } }
function fix(p) {
  let s = readFileSync(p, 'utf8'); const o = s
  s = s.replaceAll('hello@YOUR-DOMAIN.com', email).replaceAll('https://YOUR-DOMAIN.com', domain).replaceAll('<!--ADS-->', adTag)
  if (donate) s = s.replaceAll('href="#" hidden data-donate', `href="${donate}" target="_blank" rel="noopener" data-donate`)
  if (s !== o) { writeFileSync(p, s); n++ }
}
walk(dir)
if (ads) writeFileSync(join(dir, 'ads.txt'), `google.com, ${ads.replace('ca-', '')}, DIRECT, f08c47fec0942fa0\n`)
console.log(`Done. Updated ${n} files → domain ${domain}, email ${email}${ads ? ', AdSense ' + ads + ' (+ads.txt)' : ''}${donate ? ', donate link set' : ''}.`)
