# SUPERTOOLS

60 free browser tools (PDF, image, file, text, developer, generators, productivity, education).
No backend, no accounts, no API keys. Files never leave your device. All libraries are bundled (no CDN needed).

## Run
    npm install
    npm run dev

## Build
    npm run build      # outputs ./dist

## Publish free
- Any host: upload the contents of `dist/` (already built in this zip).
- Netlify / Cloudflare Pages: build command `npm run build`, output dir `dist`.
- GitHub Pages: push the repo, then deploy `dist/` (e.g. `npx gh-pages -d dist`).

## Open without a server
`dist/index.html` works by simply double-clicking it (the build is a single classic script, not ES modules).
