import { defineConfig } from 'vite'

// Makes dist/index.html work everywhere: double-click (file://), any folder, any static host.
// Browsers block <script type="module"> on file:// URLs, so we build one classic (IIFE) script instead.
const classicScript = () => ({
  name: 'classic-script',
  enforce: 'post',
  transformIndexHtml(html) {
    return html.replace(/<script type="module" crossorigin/g, '<script defer').replace(/ crossorigin/g, '')
  },
})

export default defineConfig({
  base: './',
  plugins: [classicScript()],
  build: {
    chunkSizeWarningLimit: 3000,
    rollupOptions: { output: { format: 'iife', inlineDynamicImports: true } },
  },
})
