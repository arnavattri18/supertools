// Inlines JS, CSS-in-JS and the favicon into dist/index.html -> one self-contained file.
import { readFileSync, writeFileSync, rmSync } from 'node:fs'

let html = readFileSync('dist/index.html', 'utf8')
const m = html.match(/<script defer src="\.\/(assets\/[^"]+\.js)"><\/script>/)
if (!m) throw new Error('bundle script tag not found')
const js = readFileSync('dist/' + m[1], 'utf8').replace(/<\/script/gi, '<\\/script')
const icon = 'data:image/svg+xml;base64,' + readFileSync('dist/favicon.svg').toString('base64')
html = html.replace(m[0], '').replace('href="./favicon.svg"', `href="${icon}"`)
html = html.replace('</body>', () => `<script>${js}</script>\n</body>`)
writeFileSync('dist/index.html', html)
rmSync('dist/assets', { recursive: true, force: true })
rmSync('dist/favicon.svg', { force: true })
console.log('Single-file build: dist/index.html', (html.length / 1e6).toFixed(2) + ' MB')
