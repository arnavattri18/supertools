// Generates the static website: one SEO page per tool, category pages, legal pages, sitemap, robots.txt, 404.
// Placeholders (YOUR-DOMAIN.com, email, ads, donate link) are filled by scripts/configure.mjs after the build.
import { mkdirSync, writeFileSync, copyFileSync } from 'node:fs'
import { cats, tools } from '../src/data/all.js'
import { seo } from '../src/data/seo.js'

const OUT = 'dist-site', SITE = 'https://YOUR-DOMAIN.com', EMAIL = 'hello@YOUR-DOMAIN.com', NAME = 'SUPERTOOLS'
const today = new Date().toISOString().slice(0, 10)
const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
const catOf = id => cats.find(c => c[0] === id)
const CDESC = {
  pdf: 'Merge, split, rotate and convert PDF files', image: 'Compress, resize, edit and convert images', files: 'Create and manage files and archives',
  text: 'Clean, compare, convert and transform text', dev: 'Handy utilities for developers and students who code', prod: 'Timers, notes and planners to get more done',
  edu: 'Practice, quizzes and study helpers', gen: 'Generate passwords, QR codes, colors and more', calc: 'Quick calculators for school, money and daily life', conv: 'Convert units, numbers and formats',
}
const write = (path, html) => { mkdirSync(`${OUT}/${path}`, { recursive: true }); writeFileSync(`${OUT}/${path}/index.html`, html) }

const nav = (R, active) => `<div class="logo"><a href="${R}">SUPER<b>TOOLS</b></a></div><a href="${R}"${active === 'home' ? ' class="on"' : ''}><span>🏠</span>All tools</a>` +
  cats.map(c => `<a href="${R}category/${c[0]}/"${active === c[0] ? ' class="on"' : ''}><span>${c[2]}</span>${esc(c[1])}</a>`).join('')
const footer = R => `<footer><span>© ${new Date().getFullYear()} ${NAME} — free tools that run in your browser.</span><a href="${R}about/">About</a><a href="${R}privacy/">Privacy</a><a href="${R}terms/">Terms</a><a href="${R}contact/">Contact</a><a class="donate" href="#" hidden data-donate>☕ Support this project</a></footer>`
const grid = (R, list) => `<div class="grid">${list.map(t => `<a class="card" data-id="${t.id}" href="${R}${t.id}/"><div class="ic">${t.i}</div><h3>${esc(t.n)}</h3><p>${esc(t.d)}</p></a>`).join('')}</div>`

function shell({ title, desc, path, R, main, ld = [], page, active = '', noindex = false }) {
  const url = SITE + path
  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${esc(title)}</title><meta name="description" content="${esc(desc)}"><link rel="canonical" href="${url}">${noindex ? '<meta name="robots" content="noindex">' : ''}
<meta property="og:title" content="${esc(title)}"><meta property="og:description" content="${esc(desc)}"><meta property="og:url" content="${url}"><meta property="og:type" content="website"><meta property="og:site_name" content="${NAME}"><meta name="twitter:card" content="summary">
<meta name="theme-color" content="#0b0d12"><link rel="icon" type="image/svg+xml" href="${R}favicon.svg"><link rel="stylesheet" href="${R}assets/style.css">
<script>try{document.documentElement.dataset.theme=localStorage.getItem('st-theme')||(matchMedia('(prefers-color-scheme: light)').matches?'light':'dark')}catch{}</script>
<!--ADS-->${ld.map(j => `<script type="application/ld+json">${JSON.stringify(j)}</script>`).join('')}</head>
<body><div id="app"><aside id="nav">${nav(R, active)}</aside><main><header><input id="q" type="search" placeholder="Search ${tools.length} tools…  ( press / )" autocomplete="off" aria-label="Search tools"><div id="sr"></div><button class="btn" id="th" title="Switch light/dark theme" aria-label="Toggle theme">🌓</button></header>
${main}
${footer(R)}</main></div><div id="toast"></div>
<script>window.__PAGE__=${JSON.stringify(page)}</script><script type="module" src="${R}assets/app.js"></script></body></html>`
}

/* ---------- home ---------- */
const homeMain = R => `<div id="view"><h1>Free online tools that just work</h1><p class="intro">${tools.length} free tools for PDF, images, text, calculators, developers and students — no sign-up, no uploads, no watermarks. Everything runs privately inside your browser.</p>
${cats.map(c => { const l = tools.filter(t => t.c === c[0]); return l.length ? `<section class="hero-sec"><h2><a href="${R}category/${c[0]}/" style="color:inherit;text-decoration:none">${c[2]} ${esc(c[1])}</a></h2>${grid(R, l)}</section>` : '' }).join('')}</div>`
write('.', shell({ title: `${NAME} – ${tools.length} Free Online Tools (PDF, Image, Text, Calculators)`, desc: `${tools.length} free online tools: merge PDF, compress images, QR codes, calculators, JSON formatter and more. No sign-up, private and runs in your browser.`, path: '/', R: './', main: homeMain('./'), active: 'home', page: { type: 'home', root: './' },
  ld: [{ '@context': 'https://schema.org', '@type': 'WebSite', name: NAME, url: SITE + '/' }] }).replace('<footer>', '<footer>'))

/* ---------- categories ---------- */
for (const c of cats) {
  const l = tools.filter(t => t.c === c[0]); if (!l.length) continue
  const R = '../../', title = `Free Online ${c[1]} – ${NAME}`
  write(`category/${c[0]}`, shell({ title, desc: `${CDESC[c[0]]}. ${l.length} free ${c[1].toLowerCase()} that run privately in your browser — no sign-up.`, path: `/category/${c[0]}/`, R, active: c[0], page: { type: 'cat', root: R },
    main: `<div id="view"><div class="crumbs"><a href="${R}">Home</a> › ${esc(c[1])}</div><h1>${c[2]} ${esc(c[1])}</h1><p class="intro">${CDESC[c[0]]}. All ${l.length} tools are free, need no account, and process your data on your own device.</p><section class="hero-sec">${grid(R, l)}</section></div>`,
    ld: [{ '@context': 'https://schema.org', '@type': 'CollectionPage', name: title, url: `${SITE}/category/${c[0]}/` }] }))
}

/* ---------- tool pages ---------- */
for (const t of tools) {
  const [kw, stepsRaw, tip] = seo[t.id], steps = stepsRaw.split('|'), R = '../', c = catOf(t.c), rel = tools.filter(x => x.c === t.c && x.id !== t.id).slice(0, 8)
  const faq = [
    [`Is ${t.n} really free?`, `Yes. ${t.n} is completely free with no limits, no watermarks and no sign-up.`],
    [`Is my data safe when I use ${t.n}?`, `Yes. Everything is processed on your own device inside your browser. Your files and text are never uploaded to a server.`],
    [`Does ${t.n} work on my phone?`, `Yes. It works in any modern browser on phones, tablets and computers.`],
    [`Any tips for using ${t.n}?`, tip],
  ]
  const desc = `${kw}. ${t.d} Free, private and instant — no sign-up.`.slice(0, 158)
  const url = `${SITE}/${t.id}/`
  write(t.id, shell({ title: `${kw} – Free & Private | ${NAME}`, desc, path: `/${t.id}/`, R, active: t.c, page: { type: 'tool', id: t.id, root: R },
    ld: [
      { '@context': 'https://schema.org', '@type': 'WebApplication', name: kw, url, description: t.d, applicationCategory: 'UtilitiesApplication', operatingSystem: 'Any', offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' } },
      { '@context': 'https://schema.org', '@type': 'BreadcrumbList', itemListElement: [[NAME, SITE + '/'], [c[1], `${SITE}/category/${c[0]}/`], [t.n, url]].map(([n, u], i) => ({ '@type': 'ListItem', position: i + 1, name: n, item: u })) },
      { '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: faq.map(([q, a]) => ({ '@type': 'Question', name: q, acceptedAnswer: { '@type': 'Answer', text: a } })) },
    ],
    main: `<div id="view"><div class="crumbs"><a href="${R}">Home</a> › <a href="${R}category/${c[0]}/">${esc(c[1])}</a> › ${esc(t.n)}</div>
<h1>${t.i} ${esc(kw)}<span class="free">100% free · runs in your browser</span></h1><p class="sub">${esc(t.d)} Your data never leaves your device.</p>
<div class="panel" id="tool-mount"><p class="mut">Loading tool…</p><noscript><p>Please enable JavaScript to use this tool.</p></noscript></div></div>
<section id="seo"><h2>How to use ${esc(t.n)}</h2><ol>${steps.map(s => `<li>${esc(s)}</li>`).join('')}</ol>
<h2>Why use ${esc(t.n)} on ${NAME}?</h2><p>${esc(t.n)} is free and works entirely inside your browser. Your input is processed on your own device and is never uploaded to a server, so it is fast, private and works even on a slow connection. There is nothing to install and no account to create.</p>
<h2>Frequently asked questions</h2>${faq.map(([q, a]) => `<details><summary>${esc(q)}</summary><p>${esc(a)}</p></details>`).join('')}
${rel.length ? `<h2>More ${esc(c[1])}</h2><div class="related">${rel.map(x => `<a href="${R}${x.id}/">${x.i} ${esc(x.n)}</a>`).join('')}</div>` : ''}</section>` }))
}

/* ---------- info pages ---------- */
const info = (slug, title, desc, body) => write(slug, shell({ title: `${title} – ${NAME}`, desc, path: `/${slug}/`, R: '../', page: { type: 'info', root: '../' }, main: `<div id="view" class="page"><h1>${title}</h1>${body}</div>` }))
info('about', 'About', `About ${NAME}: free, private online tools that run in your browser.`, `<p>${NAME} is a collection of ${tools.length} free online tools for PDF, images, text, calculators, developers and students. The goal is simple: tools that are fast, free, and respect your privacy.</p>
<h2>How it works</h2><p>Every tool runs inside your own browser. When you merge a PDF or compress an image, the work happens on your device — your files are not sent to our servers, because there is no server processing them.</p>
<h2>Why free?</h2><p>The site is supported by optional donations and, in the future, non-intrusive advertising. The tools stay free to use.</p>
<h2>Get in touch</h2><p>Found a bug or want a new tool? <a href="../contact/">Contact us</a>.</p>`)
info('privacy', 'Privacy Policy', `How ${NAME} handles your data: your files stay on your device.`, `<p><em>Last updated: ${today}</em></p>
<h2>Your files and text</h2><p>${NAME} tools run in your browser. Files, images, PDFs and text you use with a tool are processed locally on your device and are <b>not uploaded</b> to our servers.</p>
<h2>Data stored on your device</h2><p>We use your browser's local storage to remember preferences such as light/dark theme, favorite tools, recently used tools, flashcard decks, notes and to-do items. This data stays on your device and you can clear it from your browser settings at any time.</p>
<h2>Cookies and advertising</h2><p>We may show ads from third-party networks such as Google AdSense. These providers may use cookies to serve ads based on your visits to this and other websites. You can learn how Google uses data at <a href="https://policies.google.com/technologies/partner-sites" rel="noopener" target="_blank">policies.google.com/technologies/partner-sites</a> and opt out of personalised ads at <a href="https://adssettings.google.com" rel="noopener" target="_blank">adssettings.google.com</a>.</p>
<h2>Analytics</h2><p>We do not collect personal information. If we use privacy-friendly analytics in future, it will only count page visits.</p>
<h2>Children</h2><p>The site does not knowingly collect personal information from anyone, including children.</p>
<h2>Contact</h2><p>Questions about this policy? Email <a href="mailto:${EMAIL}">${EMAIL}</a>.</p>`)
info('terms', 'Terms of Use', `Terms of use for ${NAME}.`, `<p><em>Last updated: ${today}</em></p><p>By using ${NAME} you agree to these terms.</p>
<h2>Use of the tools</h2><p>The tools are provided free of charge, "as is", without warranties of any kind. Always keep a backup of important files; we are not responsible for any loss or damage resulting from use of the tools.</p>
<h2>Acceptable use</h2><p>Do not use the site to break the law or infringe other people's rights. Do not attempt to disrupt the site.</p>
<h2>Calculators and information</h2><p>Calculators (such as BMI, EMI and grades) give general estimates and are not medical, financial or legal advice.</p>
<h2>Changes</h2><p>We may update these terms and the tools at any time.</p><h2>Contact</h2><p><a href="mailto:${EMAIL}">${EMAIL}</a></p>`)
info('contact', 'Contact', `Contact ${NAME} — report a bug, suggest a tool or say hello.`, `<p>We'd love to hear from you — bug reports, tool requests and feedback are all welcome.</p><p>Email: <a href="mailto:${EMAIL}">${EMAIL}</a></p><p>Please include the tool name and your browser if you are reporting a problem.</p>`)

/* ---------- 404, sitemap, robots, favicon ---------- */
writeFileSync(`${OUT}/404.html`, shell({ title: `Page not found – ${NAME}`, desc: 'Page not found.', path: '/404.html', R: '/', noindex: true, page: { type: 'info', root: '/' }, main: `<div id="view" class="page"><h1>Page not found</h1><p>That page doesn't exist. <a href="/">Browse all ${tools.length} tools →</a></p></div>` }))
const urls = ['/', ...cats.filter(c => tools.some(t => t.c === c[0])).map(c => `/category/${c[0]}/`), ...tools.map(t => `/${t.id}/`), '/about/', '/privacy/', '/terms/', '/contact/']
writeFileSync(`${OUT}/sitemap.xml`, `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map(u => `<url><loc>${SITE}${u}</loc><lastmod>${today}</lastmod></url>`).join('\n')}\n</urlset>\n`)
writeFileSync(`${OUT}/robots.txt`, `User-agent: *\nAllow: /\n\nSitemap: ${SITE}/sitemap.xml\n`)
copyFileSync('public/favicon.svg', `${OUT}/favicon.svg`)
console.log(`Website built: ${urls.length} pages in ${OUT}/`)
