export const $=s=>document.querySelector(s);
export const E=(t,a={},...c)=>{const e=document.createElement(t);for(const k in a){k.startsWith('on')?e.addEventListener(k.slice(2),a[k]):k==='class'?e.className=a[k]:k in e?e[k]=a[k]:e.setAttribute(k,a[k])}c.flat().forEach(x=>x!=null&&x!==false&&e.append(x.nodeType?x:document.createTextNode(x)));return e};
export const ST={g(k,d){try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}},s(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch{}}};
export const kb=n=>n>1e6?(n/1e6).toFixed(2)+' MB':(n/1e3).toFixed(1)+' KB';
let tt;export const toast=(m,ms=2200)=>{const t=$('#toast');t.textContent=m;t.style.display='block';clearTimeout(tt);tt=setTimeout(()=>t.style.display='none',ms)};
export const busy=async f=>{toast('Working…',1e5);try{await f();toast('Done ✓')}catch(e){toast('Error: '+(e.message||e),5000)}};
export const btn=(t,f,c='')=>E('button',{class:'btn '+c,onclick:f},t);
export const copy=async t=>{try{await navigator.clipboard.writeText(t);toast('Copied ✓')}catch{toast('Copy blocked — select the text manually')}};
export const save=async(b,n)=>{if(!(b instanceof Blob))b=new Blob([b]);let d=null;try{d=await window.claude?.use('downloads')}catch{}
 if(d){try{await d.save({filename:n,data:b})}catch(e){if(e.code!=='declined')toast('Save failed: '+(e.message||e.code))}return}
 const a=E('a',{href:URL.createObjectURL(b),download:n});document.body.append(a);a.click();a.remove()};
export const L={
 pdf:async()=>{window.PDFLib=await import("pdf-lib")},
 zip:async()=>{window.JSZip=(await import("jszip")).default},
 qr:async()=>{window.qrcode=(await import("qrcode-generator")).default},
 pjs:async()=>{const [p,w]=await Promise.all([import("pdfjs-dist/build/pdf.js"),import("pdfjs-dist/build/pdf.worker.min.js")]);window.pdfjsWorker=w.WorkerMessageHandler?w:(w.default||w);window.pdfjsLib=p}};
export const drop=(acc,multi,cb,label)=>{const i=E('input',{type:'file',accept:acc,multiple:multi,hidden:true,onchange:()=>{cb([...i.files]);i.value=''}});
 const z=E('div',{class:'drop',onclick:()=>i.click(),ondragover:e=>{e.preventDefault();z.classList.add('on')},ondragleave:()=>z.classList.remove('on'),ondrop:e=>{e.preventDefault();z.classList.remove('on');cb([...e.dataTransfer.files])}},label||'Click or drop files here');return E('div',{},z,i)};
export const rng=(s,n)=>{const o=[];for(const p of s.split(',')){const m=p.trim().match(/^(\d+)(?:-(\d+))?$/);if(!m)throw Error('Bad range: "'+p.trim()+'"');const a=+m[1],b=+(m[2]||m[1]);if(a<1||b>n||a>b)throw Error('Out of range (1–'+n+'): '+p.trim());for(let i=a;i<=b;i++)o.push(i-1)}return o};
export const toBlob=(c,t,q)=>new Promise(r=>c.toBlob(r,t,q));
export const zipOf=async items=>{await L.zip();const z=new JSZip();items.forEach(([n,b])=>z.file(n,b));return z.generateAsync({type:'blob',compression:'DEFLATE'})};
export const base=n=>n.replace(/\.[^.]+$/,'');
export const hooks={cleanup:()=>{}};
