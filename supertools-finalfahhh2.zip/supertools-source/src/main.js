import "./styles/index.css";
import { $, E, ST, btn, hooks } from "./utils/helpers.js";
import { cats as c1, tools as t1 } from "./data/tools.js";
import { tools2 } from "./data/tools2.js";
const cats = [...c1, ["calc", "Calculators", "🧮"], ["conv", "Converters", "🔁"]];
const tools = [...t1, ...tools2];

/* ---------- app shell ---------- */
let fav=ST.g('st-fav',[]),rec=ST.g('st-rec',[]);
const card=t=>E('div',{class:'card',onclick:()=>location.hash='#/t/'+t.id},E('button',{class:'star'+(fav.includes(t.id)?' on':''),title:'Favorite',onclick:e=>{e.stopPropagation();fav=fav.includes(t.id)?fav.filter(x=>x!==t.id):[...fav,t.id];ST.s('st-fav',fav);route()}},'★'),E('div',{class:'ic'},t.i),E('h3',{},t.n),E('p',{},t.d));
const grid=a=>a.length?E('div',{class:'grid'},a.map(card)):E('p',{class:'mut'},'Nothing here yet.');
const nav=[['home','🏠','Dashboard'],...cats.map(c=>[c[0],c[2],c[1]]),['fav','★','Favorites'],['rec','🕘','Recent']];
function route(){hooks.cleanup();hooks.cleanup=()=>{};const h=location.hash.replace(/^#\/?/,'')||'home',v=$('#view');v.replaceChildren();$('#q').value='';
 $('#nav').replaceChildren(E('div',{class:'logo'},'SUPER',E('b',{},'TOOLS')),...nav.map(([id,ic,lb])=>E('a',{class:(h===id||(h.startsWith('t/')&&tools.find(t=>t.id===h.slice(2))?.c===id))?'on':'',onclick:()=>location.hash='#/'+id},E('span',{},ic),lb)));
 if(h.startsWith('t/')){const t=tools.find(x=>x.id===h.slice(2));if(!t){location.hash='#/home';return}rec=[t.id,...rec.filter(x=>x!==t.id)].slice(0,12);ST.s('st-rec',rec);const p=E('div',{class:'panel'});
  v.append(E('span',{class:'crumb',onclick:()=>history.back()},'← Back'),E('h1',{},t.i+' '+t.n,E('span',{class:'free'},'100% free · runs in your browser')),E('p',{class:'sub'},t.d+' Your files never leave this device.'),p);t.run(p);return}
 if(h==='home'){v.append(E('h1',{},'Powerful tools. One place.'),E('p',{class:'sub'},tools.length+' tools · no sign-up · no uploads · no tracking · completely free.'));
  if(rec.length)v.append(E('h2',{},'Recent'),grid(rec.map(id=>tools.find(t=>t.id===id)).filter(Boolean).slice(0,4)));v.append(E('h2',{},'All tools'),grid(tools));return}
 if(h==='fav'){v.append(E('h1',{},'Favorites'),grid(tools.filter(t=>fav.includes(t.id))));return}
 if(h==='rec'){v.append(E('h1',{},'Recent'),rec.length?btn('Clear',()=>{rec=[];ST.s('st-rec',rec);route()}):'',grid(rec.map(id=>tools.find(t=>t.id===id)).filter(Boolean)));return}
 const c=cats.find(x=>x[0]===h);v.append(E('h1',{},c?c[1]:'Not found'),grid(tools.filter(t=>t.c===h)))}
$('#q').oninput=e=>{const s=e.target.value.toLowerCase().trim();if(!s)return route();const v=$('#view');v.replaceChildren(E('h1',{},'Search results'),grid(tools.filter(t=>(t.n+' '+t.d+' '+t.id).toLowerCase().includes(s))))};
$('#th').onclick=()=>{const t=document.documentElement.dataset.theme==='light'?'dark':'light';document.documentElement.dataset.theme=t;try{localStorage.setItem('st-theme',t)}catch{}};
addEventListener('keydown',e=>{if(e.key==='/'&&!/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)){e.preventDefault();$('#q').focus()}});
addEventListener('hashchange',route);route();
