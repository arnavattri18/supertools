import { $, E, ST, kb, toast, busy, btn, copy, save, L, drop, rng, toBlob, zipOf, base, hooks } from "../utils/helpers.js";

/* ---------- image tool (compress + resize) ---------- */
function imgTool(r,resize){let fs=[];const out=E('div',{class:'list'});
 const q=E('input',{type:'range',min:.1,max:1,step:.05,value:resize?.92:.7}),ql=E('span',{class:'mut'}),w=E('input',{type:'number',min:1,placeholder:resize?'Width px':'Max width px (optional)',style:'width:170px'}),h=E('input',{type:'number',min:1,placeholder:'Height px',style:'width:120px'}),
 f=E('select',{},...(resize?['png','jpeg','webp']:['jpeg','webp']).map(x=>E('option',{value:x},x.toUpperCase())));
 q.oninput=()=>ql.textContent=Math.round(q.value*100)+'%';q.oninput();
 const go=()=>busy(async()=>{if(!fs.length)throw Error('Add images first');const res=[];out.replaceChildren();
  for(const file of fs){const b=await createImageBitmap(file);let W=+w.value||0,H=resize?(+h.value||0):0;
   if(resize){W=W||(H?Math.round(b.width*H/b.height):b.width);H=H||(+w.value?Math.round(b.height*W/b.width):b.height)}else{if(!W||W>b.width)W=b.width;H=Math.round(b.height*W/b.width)}
   const c=E('canvas');c.width=W;c.height=H;const x=c.getContext('2d');if(f.value==='jpeg'){x.fillStyle='#fff';x.fillRect(0,0,W,H)}x.drawImage(b,0,0,W,H);
   const blob=await toBlob(c,'image/'+f.value,+q.value),nm=base(file.name)+(resize?`-${W}x${H}`:'-min')+'.'+(f.value==='jpeg'?'jpg':f.value);res.push([nm,blob]);
   out.append(E('div',{class:'row'},E('span',{},nm),E('span',{class:'mut'},`${kb(file.size)} → ${kb(blob.size)}${resize?'':' ('+Math.round((1-blob.size/file.size)*100)+'% smaller)'}`),E('span',{class:'sp'}),btn('Save',()=>save(blob,nm))))}
  if(res.length>1)out.append(btn('Save all as ZIP',()=>busy(async()=>save(await zipOf(res),'images.zip')),'pri'))});
 r.append(drop('image/*',true,a=>{fs=a.filter(x=>x.type.startsWith('image/'));out.replaceChildren(E('div',{class:'mut'},fs.length+' image(s) ready'))},'Click or drop images here'),
  E('div',{class:'row'},w,resize&&h,E('label',{},'Format'),f,E('label',{},'Quality'),q,ql),resize&&E('div',{class:'mut'},'Fill one size to keep the aspect ratio, or both for an exact size.'),btn(resize?'Resize':'Compress',go,'pri'),out)}

/* ---------- tool registry ---------- */
export const cats=[['pdf','PDF Tools','📄'],['image','Image Tools','🖼️'],['files','File Tools','📁'],['text','Text Tools','✍️'],['dev','Developer Tools','💻'],['prod','Productivity','⏱️'],['edu','Education','🎓'],['gen','Generators','✨']];
export const tools=[
{id:'pdf-merger',n:'PDF Merger',c:'pdf',i:'📚',d:'Merge multiple PDF files into one document.',run(r){let fs=[];const list=E('div',{class:'list'});
 const draw=()=>list.replaceChildren(...fs.map((f,i)=>E('div',{class:'row'},E('span',{},f.name),E('span',{class:'mut'},kb(f.size)),E('span',{class:'sp'}),btn('↑',()=>{if(i){[fs[i-1],fs[i]]=[fs[i],fs[i-1]];draw()}}),btn('↓',()=>{if(i<fs.length-1){[fs[i+1],fs[i]]=[fs[i],fs[i+1]];draw()}}),btn('✕',()=>{fs.splice(i,1);draw()}))));
 r.append(drop('.pdf,application/pdf',true,a=>{fs.push(...a.filter(f=>/\.pdf$/i.test(f.name)));draw()},'Click or drop PDFs here (order = merge order)'),list,btn('Merge & download',()=>busy(async()=>{if(fs.length<2)throw Error('Add at least 2 PDFs');await L.pdf();const o=await PDFLib.PDFDocument.create();
  for(const f of fs){const d=await PDFLib.PDFDocument.load(await f.arrayBuffer(),{ignoreEncryption:true});(await o.copyPages(d,d.getPageIndices())).forEach(p=>o.addPage(p))}save(new Blob([await o.save()]),'merged.pdf')}),'pri'))}},
{id:'pdf-splitter',n:'PDF Splitter',c:'pdf',i:'✂️',d:'Split a PDF into selected pages or page ranges.',run(r){let file,src,np=0;const info=E('div',{class:'mut'}),rg=E('input',{placeholder:'e.g. 1-3, 5, 8-10',style:'width:260px'});
 const ld=async()=>{await L.pdf();return PDFLib.PDFDocument.load(await file.arrayBuffer(),{ignoreEncryption:true})};
 r.append(drop('.pdf,application/pdf',false,a=>busy(async()=>{file=a[0];src=await ld();np=src.getPageCount();info.textContent=file.name+' — '+np+' pages'})),info,E('div',{class:'row'},E('label',{},'Pages'),rg),
 E('div',{class:'row'},btn('Extract pages → one PDF',()=>busy(async()=>{if(!src)throw Error('Choose a PDF first');const ix=rng(rg.value,np),o=await PDFLib.PDFDocument.create();(await o.copyPages(src,ix)).forEach(p=>o.addPage(p));save(new Blob([await o.save()]),base(file.name)+'-extract.pdf')}),'pri'),
 btn('Every page → ZIP',()=>busy(async()=>{if(!src)throw Error('Choose a PDF first');const it=[];for(let i=0;i<np;i++){const o=await PDFLib.PDFDocument.create();o.addPage((await o.copyPages(src,[i]))[0]);it.push([`${base(file.name)}-p${i+1}.pdf`,await o.save()])}save(await zipOf(it),base(file.name)+'-pages.zip')}))))}},
{id:'pdf-to-images',n:'PDF to Images',c:'pdf',i:'🖼️',d:'Convert PDF pages into PNG image files.',run(r){const th=E('div',{class:'thumbs'}),sc=E('select',{},...[1,1.5,2,3].map(x=>E('option',{value:x,selected:x===2},x+'× quality')));let res=[];
 r.append(drop('.pdf,application/pdf',false,a=>busy(async()=>{await L.pjs();th.replaceChildren();res=[];const d=await pdfjsLib.getDocument({data:await a[0].arrayBuffer()}).promise;
  for(let p=1;p<=d.numPages;p++){const pg=await d.getPage(p),vp=pg.getViewport({scale:+sc.value}),c=E('canvas');c.width=vp.width;c.height=vp.height;await pg.render({canvasContext:c.getContext('2d'),viewport:vp}).promise;
   const b=await toBlob(c,'image/png'),nm=`${base(a[0].name)}-p${p}.png`;res.push([nm,b]);th.append(E('div',{},E('img',{src:URL.createObjectURL(b)}),E('div',{class:'row'},E('span',{class:'mut'},'Page '+p),E('span',{class:'sp'}),btn('Save',()=>save(b,nm)))))}})),
 E('div',{class:'row'},E('label',{},'Quality'),sc,btn('Save all as ZIP',()=>busy(async()=>{if(!res.length)throw Error('Convert a PDF first');save(await zipOf(res),'pdf-pages.zip')}),'pri')),th)}},
{id:'image-compressor',n:'Image Compressor',c:'image',i:'🗜️',d:'Reduce image file size while keeping useful quality.',run:r=>imgTool(r,false)},
{id:'image-resizer',n:'Image Resizer',c:'image',i:'↔️',d:'Resize images using custom dimensions.',run:r=>imgTool(r,true)},
{id:'zip-creator',n:'ZIP Creator',c:'files',i:'🗃️',d:'Create ZIP archives directly in your browser.',run(r){let fs=[];const list=E('div',{class:'list'}),nm=E('input',{value:'archive'});
 const draw=()=>list.replaceChildren(...fs.map((f,i)=>E('div',{class:'row'},E('span',{},f.name),E('span',{class:'mut'},kb(f.size)),E('span',{class:'sp'}),btn('✕',()=>{fs.splice(i,1);draw()}))));
 r.append(drop('',true,a=>{fs.push(...a);draw()},'Click or drop any files'),list,E('div',{class:'row'},nm,E('span',{class:'mut'},'.zip'),btn('Create ZIP',()=>busy(async()=>{if(!fs.length)throw Error('Add some files');save(await zipOf(fs.map(f=>[f.name,f])),(nm.value||'archive')+'.zip')}),'pri')))}},
{id:'json-formatter',n:'JSON Formatter',c:'dev',i:'🧩',d:'Format, validate and minify JSON data.',run(r){const a=E('textarea',{placeholder:'Paste JSON here…'}),m=E('div',{class:'mut'}),ind=E('select',{},E('option',{value:2},'2 spaces'),E('option',{value:4},'4 spaces'),E('option',{value:'\t'},'Tab'));
 const f=fn=>()=>{try{const v=JSON.parse(a.value);a.value=fn(v);m.style.color='var(--ok)';m.textContent='✓ Valid JSON'}catch(e){m.style.color='var(--bad)';m.textContent='✗ '+e.message}};
 r.append(a,E('div',{class:'row'},btn('Format',f(v=>JSON.stringify(v,null,ind.value==='\t'?'\t':+ind.value)),'pri'),btn('Minify',f(v=>JSON.stringify(v))),btn('Validate',f(()=>a.value)),ind,btn('Copy',()=>copy(a.value))),m)}},
{id:'base64',n:'Base64 Encoder',c:'dev',i:'🔣',d:'Encode and decode Base64 text locally.',run(r){const a=E('textarea',{placeholder:'Text or Base64…'}),m=E('div',{class:'mut'});
 r.append(a,E('div',{class:'row'},btn('Encode',()=>{let s='';new TextEncoder().encode(a.value).forEach(b=>s+=String.fromCharCode(b));a.value=btoa(s);m.textContent=''},'pri'),
 btn('Decode',()=>{try{a.value=new TextDecoder().decode(Uint8Array.from(atob(a.value.trim().replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0)));m.textContent=''}catch{m.style.color='var(--bad)';m.textContent='✗ Not valid Base64'}}),btn('Copy',()=>copy(a.value))),m)}},
{id:'uuid-generator',n:'UUID Generator',c:'gen',i:'🆔',d:'Generate UUID v4 identifiers locally.',run(r){const n=E('input',{type:'number',min:1,max:500,value:5,style:'width:90px'}),o=E('textarea',{readOnly:true,style:'min-height:180px'});
 const g=()=>o.value=Array.from({length:Math.min(500,Math.max(1,+n.value||1))},()=>crypto.randomUUID()).join('\n');g();r.append(E('div',{class:'row'},E('label',{},'How many'),n,btn('Generate',g,'pri'),btn('Copy',()=>copy(o.value))),o)}},
{id:'qr-generator',n:'QR Code Generator',c:'gen',i:'🔳',d:'Generate QR codes directly in your browser.',run(r){const t=E('textarea',{style:'min-height:90px',placeholder:'Text or URL…'}),cv=E('canvas',{style:'max-width:100%;border-radius:8px;background:#fff'}),e=E('select',{},...['L','M','Q','H'].map(x=>E('option',{value:x,selected:x==='M'},'Error fix '+x))),sz=E('select',{},...[256,512,1024].map(x=>E('option',{value:x,selected:x===512},x+' px')));
 const g=()=>busy(async()=>{if(!t.value)return;await L.qr();const q=qrcode(0,e.value);q.addData(t.value);q.make();const n=q.getModuleCount(),s=Math.max(1,Math.floor(+sz.value/(n+8))),S=(n+8)*s;cv.width=cv.height=S;const x=cv.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,S,S);x.fillStyle='#000';
  for(let a=0;a<n;a++)for(let b=0;b<n;b++)if(q.isDark(a,b))x.fillRect((b+4)*s,(a+4)*s,s,s)});
 t.oninput=g;e.onchange=g;sz.onchange=g;r.append(t,E('div',{class:'row'},e,sz,btn('Save PNG',async()=>{if(!t.value)return toast('Enter some text first');save(await toBlob(cv,'image/png'),'qrcode.png')},'pri')),cv)}},
{id:'password-generator',n:'Password Generator',c:'gen',i:'🔑',d:'Generate strong random passwords locally.',run(r){const len=E('input',{type:'range',min:8,max:64,value:20}),ll=E('b',{},'20'),o=E('input',{readOnly:true,style:'width:100%;font:18px ui-monospace,monospace'}),m=E('div',{class:'mut'});
 const sets={Lowercase:'abcdefghijkmnopqrstuvwxyz',Uppercase:'ABCDEFGHJKLMNPQRSTUVWXYZ',Numbers:'23456789',Symbols:'!@#$%^&*()-_=+[]{};:,.?'},ck={};
 const rnd=n=>{const a=new Uint32Array(1),lim=2**32-2**32%n;do crypto.getRandomValues(a);while(a[0]>=lim);return a[0]%n};
 const g=()=>{const on=Object.keys(sets).filter(k=>ck[k].checked);if(!on.length){o.value='';m.textContent='Pick at least one set';return}const all=on.map(k=>sets[k]).join(''),n=+len.value;ll.textContent=n;
  const p=on.map(k=>sets[k][rnd(sets[k].length)]);while(p.length<n)p.push(all[rnd(all.length)]);for(let i=p.length-1;i>0;i--){const j=rnd(i+1);[p[i],p[j]]=[p[j],p[i]]}o.value=p.join('');const bits=Math.round(n*Math.log2(all.length));m.textContent=`≈ ${bits} bits of entropy — ${bits<60?'weak':bits<90?'good':'excellent'}`};
 len.oninput=g;r.append(o,E('div',{class:'row'},E('label',{},'Length'),len,ll),E('div',{class:'row'},...Object.keys(sets).map(k=>E('label',{},ck[k]=E('input',{type:'checkbox',checked:true,onchange:g}),' '+k))),m,E('div',{class:'row'},btn('Generate',g,'pri'),btn('Copy',()=>copy(o.value))));g()}},
{id:'word-counter',n:'Word Counter',c:'text',i:'🔢',d:'Count words, characters, sentences and paragraphs.',run(r){const a=E('textarea',{placeholder:'Type or paste text…'}),s=E('div',{class:'stats'});
 const u=()=>{const t=a.value,w=(t.match(/[\p{L}\p{N}'’-]+/gu)||[]).length;const v=[['Words',w],['Characters',t.length],['No spaces',t.replace(/\s/g,'').length],['Sentences',(t.match(/[^.!?]+[.!?]+/g)||(t.trim()?[1]:[])).length],['Paragraphs',t.split(/\n\s*\n/).filter(x=>x.trim()).length],['Reading time',Math.ceil(w/200)+' min']];
  s.replaceChildren(...v.map(([k,x])=>E('div',{},E('b',{},x),k)))};a.oninput=u;u();r.append(s,a)}},
{id:'case-converter',n:'Case Converter',c:'text',i:'🔠',d:'Convert text between different letter cases.',run(r){const a=E('textarea',{placeholder:'Type or paste text…'});
 const W=t=>t.replace(/([a-z0-9])([A-Z])/g,'$1 $2').match(/[\p{L}\p{N}]+/gu)||[],cap=w=>w[0].toUpperCase()+w.slice(1).toLowerCase();
 const m={'UPPER CASE':t=>t.toUpperCase(),'lower case':t=>t.toLowerCase(),'Title Case':t=>t.toLowerCase().replace(/(^|\s|[-(])(\p{L})/gu,(_,p,c)=>p+c.toUpperCase()),'Sentence case':t=>t.toLowerCase().replace(/(^\s*|[.!?]\s+)(\p{L})/gu,(_,p,c)=>p+c.toUpperCase()),
 camelCase:t=>W(t).map((w,i)=>i?cap(w):w.toLowerCase()).join(''),PascalCase:t=>W(t).map(cap).join(''),snake_case:t=>W(t).join('_').toLowerCase(),'kebab-case':t=>W(t).join('-').toLowerCase(),CONSTANT_CASE:t=>W(t).join('_').toUpperCase()};
 r.append(a,E('div',{class:'row'},...Object.entries(m).map(([k,f])=>btn(k,()=>a.value=f(a.value)))),E('div',{class:'row'},btn('Copy',()=>copy(a.value),'pri')))}},
{id:'pomodoro',n:'Pomodoro Timer',c:'prod',i:'🍅',d:'Focus with customizable work and break sessions.',run(r){const P={w:25,s:5,l:15},inp={};let mode='w',left=P.w*60,end=0,tm=null,done=0;const disp=E('div',{class:'big'}),lab=E('div',{class:'mut',style:'text-align:center'});const nm={w:'Focus',s:'Short break',l:'Long break'};
 const show=()=>{const m=String(Math.floor(left/60)).padStart(2,'0'),s=String(left%60).padStart(2,'0');disp.textContent=m+':'+s;lab.textContent=`${nm[mode]} · ${done} session(s) done`;document.title=(tm?m+':'+s+' · ':'')+'SUPERTOOLS'};
 const beep=()=>{try{const c=new AudioContext(),o=c.createOscillator();o.connect(c.destination);o.frequency.value=880;o.start();o.stop(c.currentTime+.6)}catch{}};
 const set=m=>{mode=m;left=Math.round((+inp[m].value||P[m])*60);end=Date.now()+left*1e3;show()};
 const tick=()=>{left=Math.max(0,Math.round((end-Date.now())/1e3));if(!left){beep();toast(nm[mode]+' finished!',4000);if(mode==='w'){done++;set(done%4?'s':'l')}else set('w')}show()};
 const start=()=>{if(tm)return;end=Date.now()+left*1e3;tm=setInterval(tick,250);show()},stop=()=>{clearInterval(tm);tm=null;show()};
 hooks.cleanup=()=>{clearInterval(tm);document.title='SUPERTOOLS — Powerful tools. One place.'};
 r.append(lab,disp,E('div',{class:'row',style:'justify-content:center'},btn('Start',start,'pri'),btn('Pause',stop),btn('Reset',()=>{stop();set(mode)}),btn('Skip →',()=>{stop();set(mode==='w'?'s':'w')})),
 E('div',{class:'row',style:'justify-content:center'},...[['w','Focus'],['s','Short'],['l','Long']].map(([k,t])=>E('label',{},t+' min ',inp[k]=E('input',{type:'number',min:1,max:180,value:P[k],style:'width:70px',onchange:()=>{if(k===mode&&!tm)set(mode)}})))));show()}},
{id:'flashcards',n:'Flashcards',c:'edu',i:'🗂️',d:'Create and review your own flashcard decks.',run(r){let D=ST.g('st-decks',{}),cur=Object.keys(D)[0]||'',q=[],fl=false,del=false;const sv=()=>ST.s('st-decks',D),box=E('div',{class:'panel'});r.append(box);
 const startRev=()=>{q=D[cur].map((_,i)=>i).sort(()=>Math.random()-.5);fl=false};
 const draw=()=>{const sel=E('select',{onchange:()=>{cur=sel.value;startRev();draw()}},...Object.keys(D).map(k=>E('option',{value:k,selected:k===cur},k))),nn=E('input',{placeholder:'New deck name'});
  const top=E('div',{class:'row'},Object.keys(D).length?sel:E('span',{class:'mut'},'No decks yet →'),nn,btn('Create',()=>{const n=nn.value.trim();if(n&&!D[n]){D[n]=[];cur=n;sv();startRev();draw()}}),cur&&btn(del?'Click again to delete':'Delete deck',()=>{if(!del){del=true;draw();return}delete D[cur];cur=Object.keys(D)[0]||'';del=false;sv();cur&&startRev();draw()}));
  box.replaceChildren(top);if(!cur)return;const cards=D[cur];
  if(cards.length){if(!q.length&&cards.length)box.append(E('div',{class:'fc',style:'cursor:default'},'🎉 Deck complete!'),btn('Review again',()=>{startRev();draw()}));
   else{const c=cards[q[0]];box.append(E('div',{class:'mut'},q.length+' left to review'),E('div',{class:'fc',onclick:()=>{fl=!fl;draw()}},fl?c.a:c.q),E('div',{class:'row'},btn(fl?'Hide answer':'Show answer',()=>{fl=!fl;draw()}),E('span',{class:'sp'}),btn('Again',()=>{q.push(q.shift());fl=false;draw()}),btn('Got it ✓',()=>{q.shift();fl=false;draw()},'pri')))}}
  const cq=E('input',{placeholder:'Question',style:'flex:1'}),ca=E('input',{placeholder:'Answer',style:'flex:1'}),bulk=E('textarea',{style:'min-height:70px',placeholder:'Bulk add — one per line:  question :: answer'});
  box.append(E('div',{class:'row'},cq,ca,btn('Add card',()=>{if(cq.value&&ca.value){cards.push({q:cq.value,a:ca.value});sv();startRev();draw()}})),bulk,btn('Import lines',()=>{bulk.value.split('\n').forEach(l=>{const[a,...b]=l.split('::');if(a.trim()&&b.join('::').trim())cards.push({q:a.trim(),a:b.join('::').trim()})});sv();startRev();draw()}),
   ...cards.map((c,i)=>E('div',{class:'row mut'},E('span',{},c.q+' — '+c.a),E('span',{class:'sp'}),btn('✕',()=>{cards.splice(i,1);sv();startRev();draw()}))))};
 if(cur)startRev();draw()}}];
