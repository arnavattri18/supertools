import { cats as c1, tools as t1 } from "./tools.js";
import { tools2 } from "./tools2.js";

export const cats = [...c1, ["calc", "Calculators", "🧮"], ["conv", "Converters", "🔁"]];
export const tools = [...t1, ...tools2];
